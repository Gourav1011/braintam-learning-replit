import { useState, useEffect, useCallback, useMemo, useRef, Fragment, Component, type ReactNode } from "react";
import { useAuth } from "@/components/auth-provider";
import { Redirect } from "wouter";

// ── Error boundary to prevent full white-screen crashes ─────────────────────
class AdminErrorBoundary extends Component<{ children: ReactNode }, { error: Error | null }> {
  state = { error: null };
  static getDerivedStateFromError(error: Error) { return { error }; }
  render() {
    if (this.state.error) {
      const err = this.state.error as Error;
      return (
        <div className="min-h-screen flex items-center justify-center p-8" style={{ background: "#F5F7FF", fontFamily: "Poppins, sans-serif" }}>
          <div className="bg-white rounded-2xl shadow-lg p-8 max-w-lg w-full border border-red-100">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-red-50 flex items-center justify-center">
                <span className="text-red-500 text-lg font-black">!</span>
              </div>
              <div>
                <p className="font-black text-sm" style={{ color: "#0B2B6B" }}>Something went wrong</p>
                <p className="text-xs text-gray-400">Admin panel encountered an error</p>
              </div>
            </div>
            <pre className="text-xs text-red-600 bg-red-50 rounded-xl p-4 overflow-auto mb-4 max-h-40">{err.message}</pre>
            <button
              onClick={() => { this.setState({ error: null }); window.location.reload(); }}
              className="px-4 py-2 rounded-xl text-white text-sm font-semibold"
              style={{ background: "#FF6B1A" }}
            >
              Reload page
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
import {
  Users, BookOpen, GraduationCap, UserCheck, Plus, Trash2, Shield,
  ChevronRight, BarChart3, Link as LinkIcon, Bell, Image, Edit2, X,
  TrendingUp, Award, Calendar, Activity, Video, Clock,
  Eye, EyeOff, Copy, RefreshCw, Search, Filter, Download, Upload,
  CheckSquare, Square, AlertTriangle, UserX, UserCheck2, Key, FileText,
  DollarSign, LayoutDashboard, Lock, ChevronDown, ChevronUp, LogOut,
  MoreVertical, RotateCcw, CreditCard, Layers, Cpu, GraduationCap as GradCap,
  ShieldCheck, Zap, UserCircle, CheckCircle2, Globe, Loader2, User, ClipboardList,
  Mail, Phone, TrendingDown, TrendingUp as TrendUp, MoreVertical as MoreVert,
  Package,
} from "lucide-react";
import braintamLogo from "@assets/transparent_braintam_logo_1780813752895.png";
import { StaffProfileTab } from "@/components/staff-profile-tab";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { SearchableSelect } from "@/components/ui/searchable-select";
import { CourseManagementTab } from "./courses-tab";
import { DemoBatchesTab } from "./demo-batches-tab";
import { MentorsTab } from "./mentors-tab";
import { DashboardTab } from "./dashboard-tab";
import { Student360Page } from "./student360-page";
import { CourseAnalyticsTab } from "./course-analytics-tab";
import { TeacherAnalyticsTab } from "./teacher-analytics-tab";
import { HealthTab } from "./health-tab";
import { PaymentsTab } from "./payments-tab";
import { GamificationTab } from "./gamification-tab";
import { BtlCrmTab } from "./btl-crm-tab";
import { EmployeeAttendanceTab } from "./employee-attendance-tab";
import { OperationsCommandCenterTab } from "./operations-command-center-tab";
import { StaffCheckin } from "@/components/staff-checkin";
import { SuperAdminTab } from "./super-admin-tab";
import { AuditLogsTab } from "./audit-logs-tab";
import { IgniteTab, IgniteContentArea, type IgniteView } from "./ignite-tab";
import { AssessmentsTab } from "./assessments-tab";
import { CommandCenterTab } from "./command-center-tab";
import { ReportsAnalyticsTab } from "./reports-analytics-tab";
import { MasteryStudentsTab } from "./mastery-students-tab";
import { MasteryPaymentVerificationTab } from "./mastery-payment-verification-tab";
import { RevenueAnalyticsTab } from "./revenue-analytics-tab";
import { MasteryDeploymentTab } from "./mastery-deployment-tab";
import { MasteryRetentionTab } from "./mastery-retention-tab";
import { MasteryAttendanceAnalyticsTab } from "./mastery-attendance-analytics-tab";
import { BlockedWordsTab } from "./blocked-words-tab";

import { API_BASE as BASE } from "@/lib/api-base";
const NAVY = "#0B2B6B";
const ORANGE = "#FF6B1A";

type Role = "admin" | "teacher" | "student";
type Tab =
  | "dashboard"
  | "analytics"
  | "overview"
  | "courses"
  | "demo-batches"
  | "users"
  | "assignments"
  | "enrollments"
  | "liveclasses"
  | "announcements"
  | "banners"
  | "audit"
  | "payments"
  | "command-center"
  | "course-analytics"
  | "teacher-analytics"
  | "health"
  | "gamification"
  | "btl-crm"
  | "mentors"
  | "employee-attendance"
  | "operations-command-center"
  | "super-admin"
  | "ignite"
  | "settings"
  | "revenue-analytics"
  | "assessments"
  | "reports-analytics"
  | "mastery-students"
  | "mastery-payments"
  | "mastery-deployment"
  | "mastery-retention"
  | "mastery-attendance"
  | "blocked-words"
  | "profile";

type UserSubTab = "active" | "deactivated" | "all";
type SortField = "name" | "role" | "grade" | "school" | "id";
type SortDir = "asc" | "desc";

interface User {
  id: number;
  name: string;
  email: string | null;
  phone: string | null;
  role: string;
  accountType?: string | null;
  grade: number;
  school: string | null;
  isActive: boolean;
  createdAt?: string;
}
const IGNITE_ACCOUNT_TYPES = ["lead", "demo_student", "paid_student"];
const isMasteryStudent = (u: User) =>
  u.role === "student" && !IGNITE_ACCOUNT_TYPES.includes(u.accountType ?? "");
interface Course { id: number; title: string; subjectName: string; subjectId?: number; grade: number; teacher: string | null; academicYearId?: number | null; courseType?: string; }
interface AcademicYear { id: number; name: string; isActive: boolean; }
interface TeacherAssignment { id: number; teacherId: number; teacherName: string; courseId: number; courseTitle: string; assignedAt: string; }
interface Enrollment { id: number; studentId: number; studentName: string; courseId: number; courseTitle: string; enrolledAt: string; }
interface Stats { totalUsers: number; totalStudents: number; totalTeachers: number; totalCourses: number; totalEnrollments: number; totalTeacherAssignments: number; }
interface Analytics {
  totals: { users: number; students: number; teachers: number; courses: number; enrollments: number };
  submissions: { homework: number; assignments: number; tests: number; gradedHomework: number };
  liveClasses: { upcoming: number; live: number };
  topStudents: { id: number; name: string; points: number; grade: number; school: string | null }[];
  recentEnrollments: { studentName: string; courseTitle: string; enrolledAt: string }[];
}
interface Announcement { id: number; title: string; body: string; grade: number | null; targetRole: string; isActive: boolean; createdAt: string; }
interface Banner { id: number; title: string; imageUrl: string; link: string | null; isActive: boolean; displayOrder: number; }
interface LiveClassItem { id: number; title: string; subjectId: number; subjectName: string; grade: number; teacher: string; teacherId: number | null; scheduledAt: string; duration: number; status: string; joinUrl: string | null; studentsJoined: number; courseId: number | null; }
interface AuditLog { id: number; actorId: number; actorName: string; actorEmail?: string; action: string; targetType: string; targetId: number; targetName: string; metadata: string | null; createdAt: string; }

interface ConfirmDialog {
  title: string;
  message: string;
  confirmLabel?: string;
  danger?: boolean;
  onConfirm: () => void;
}

function apiFetch(path: string, opts?: RequestInit) {
  const token = localStorage.getItem("braintam_staff_token");
  return fetch(`${BASE}/api${path}`, {
    ...opts,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...opts?.headers,
    },
    credentials: "include",
  });
}

const ROLE_COLORS: Record<string, string> = {
  admin: "bg-red-100 text-red-700 border-red-200",
  teacher: "bg-blue-100 text-blue-700 border-blue-200",
  student: "bg-green-100 text-green-700 border-green-200",
};

function generatePassword(length = 12): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789!@#$%";
  return Array.from({ length }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
}

function passwordStrength(pw: string): { score: number; label: string; color: string } {
  let score = 0;
  if (pw.length >= 8) score++;
  if (pw.length >= 12) score++;
  if (/[A-Z]/.test(pw)) score++;
  if (/[0-9]/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;
  if (score <= 1) return { score, label: "Weak", color: "#EF4444" };
  if (score <= 3) return { score, label: "Fair", color: "#F59E0B" };
  if (score === 4) return { score, label: "Good", color: "#3B82F6" };
  return { score, label: "Strong", color: "#22C55E" };
}

export function exportCSV(filename: string, headers: string[], rows: (string | number | null | undefined)[][]) {
  const escape = (v: string | number | null | undefined) => `"${String(v ?? "").replace(/"/g, '""')}"`;
  const csv = [headers.map(escape).join(","), ...rows.map(r => r.map(escape).join(","))].join("\n");
  const blob = new Blob([csv], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

function useDebounce<T>(value: T, delay = 300): T {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(t);
  }, [value, delay]);
  return debounced;
}

// ── Confirm Dialog ──────────────────────────────────────────────────────────
function ConfirmModal({ dialog, onClose }: { dialog: ConfirmDialog; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full p-6 space-y-4">
        <div className="flex items-center gap-3">
          <div className={`w-10 h-10 rounded-full flex items-center justify-center ${dialog.danger ? "bg-red-100" : "bg-orange-100"}`}>
            <AlertTriangle className={`w-5 h-5 ${dialog.danger ? "text-red-500" : "text-orange-500"}`} />
          </div>
          <div>
            <h3 className="font-bold text-sm" style={{ color: NAVY }}>{dialog.title}</h3>
            <p className="text-xs text-gray-500 mt-0.5">{dialog.message}</p>
          </div>
        </div>
        <div className="flex gap-2 pt-1">
          <Button size="sm" onClick={() => { dialog.onConfirm(); onClose(); }}
            className={`text-white flex-1 ${dialog.danger ? "bg-red-500 hover:bg-red-600" : ""}`}
            style={dialog.danger ? {} : { background: ORANGE }}>
            {dialog.confirmLabel ?? "Confirm"}
          </Button>
          <Button size="sm" variant="ghost" onClick={onClose} className="flex-1">Cancel</Button>
        </div>
      </div>
    </div>
  );
}

// ── Profile Modal ───────────────────────────────────────────────────────────
function ProfileModal({ user, onClose, onDeactivate, onReactivate, onResetPassword, onEnroll, flash }: {
  user: User;
  onClose: () => void;
  onDeactivate: (id: number) => void;
  onReactivate: (id: number) => void;
  onResetPassword: (user: User) => void;
  onEnroll: (user: User) => void;
  flash: (msg: string, ok?: boolean) => void;
}) {
  const [enrollmentCount, setEnrollmentCount] = useState<number | null>(null);
  const [editing, setEditing] = useState(false);
  const [editName, setEditName] = useState(user.name);
  const [editSchool, setEditSchool] = useState(user.school ?? "");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    apiFetch(`/admin/users/${user.id}/courses`)
      .then(r => r.ok ? r.json() : [])
      .then((data: { enrolled: boolean }[]) =>
        setEnrollmentCount(Array.isArray(data) ? data.filter((c: { enrolled: boolean }) => c.enrolled).length : 0)
      )
      .catch(() => setEnrollmentCount(0));
  }, [user.id]);

  const saveEdit = async () => {
    if (!editName.trim()) return;
    setSaving(true);
    const r = await apiFetch(`/admin/users/${user.id}`, {
      method: "PATCH",
      body: JSON.stringify({ name: editName.trim(), school: editSchool.trim() || null }),
    });
    setSaving(false);
    if (r.ok) { flash("Profile updated!"); setEditing(false); }
    else flash("Failed to update profile", false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 space-y-4">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-white text-2xl font-black flex-shrink-0"
              style={{ background: NAVY }}>{(editName || user.name)[0]?.toUpperCase()}</div>
            <div>
              <div className="font-black text-base" style={{ color: NAVY }}>{user.name}</div>
              <span className={`text-xs px-2 py-0.5 rounded-full border font-semibold ${ROLE_COLORS[user.role] ?? ""}`}>{user.role}</span>
              {!user.isActive && <span className="ml-1 text-xs px-2 py-0.5 rounded-full bg-red-100 text-red-600 border border-red-200">Inactive</span>}
            </div>
          </div>
          <div className="flex items-center gap-1">
            {user.role !== "admin" && user.role !== "super_admin" && (
              <button onClick={() => setEditing(p => !p)} title="Edit name & school"
                className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors">
                <Edit2 className="w-4 h-4 text-gray-400" />
              </button>
            )}
            <button onClick={onClose}><X className="w-5 h-5 text-gray-400 hover:text-gray-600" /></button>
          </div>
        </div>

        {editing ? (
          <div className="space-y-2 border border-blue-100 rounded-xl p-3 bg-blue-50/40">
            <p className="text-xs font-semibold text-blue-700">Edit Profile</p>
            <div>
              <label className="text-[11px] text-gray-500 font-medium">Full Name</label>
              <Input value={editName} onChange={e => setEditName(e.target.value)} className="mt-1 text-sm h-8" />
            </div>
            <div>
              <label className="text-[11px] text-gray-500 font-medium">School Name</label>
              <Input value={editSchool} onChange={e => setEditSchool(e.target.value)} placeholder="School name" className="mt-1 text-sm h-8" />
            </div>
            <div className="flex gap-2 pt-1">
              <Button size="sm" onClick={saveEdit} disabled={saving || !editName.trim()} className="text-white flex-1 h-8" style={{ background: ORANGE }}>
                {saving ? "Saving…" : "Save Changes"}
              </Button>
              <Button size="sm" variant="ghost" onClick={() => { setEditing(false); setEditName(user.name); setEditSchool(user.school ?? ""); }} className="h-8">
                Cancel
              </Button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2 text-xs">
            {[
              { label: "Email", value: user.email ?? "—" },
              { label: "Phone", value: user.phone ?? "—" },
              user.role === "student" ? { label: "Grade", value: user.grade > 0 ? `Grade ${user.grade}` : "—" } : null,
              user.role === "student" ? { label: "School", value: user.school ?? "—" } : null,
              { label: "User ID", value: `#${user.id}` },
              { label: "Joined", value: user.createdAt ? new Date(user.createdAt).toLocaleDateString("en-IN") : "—" },
              user.role === "student" ? { label: "Enrollments", value: enrollmentCount === null ? "…" : `${enrollmentCount} course${enrollmentCount !== 1 ? "s" : ""}` } : null,
              { label: "Last Login", value: (user as any).lastLoginAt ? new Date((user as any).lastLoginAt).toLocaleDateString("en-IN") : "Not tracked" },
            ].filter((f): f is { label: string; value: string } => f !== null).map(f => (
              <div key={f.label} className="bg-gray-50 rounded-xl p-2.5">
                <div className="text-gray-400 font-medium">{f.label}</div>
                <div className="font-semibold text-gray-700 mt-0.5 truncate">{f.value}</div>
              </div>
            ))}
          </div>
        )}

        <div className="grid grid-cols-2 gap-2 pt-2">
          {user.role !== "super_admin" && (
            <Button size="sm" onClick={() => { onResetPassword(user); onClose(); }} variant="outline" className="gap-1.5 text-xs">
              <Key className="w-3.5 h-3.5" /> Reset Password
            </Button>
          )}
          {user.role === "student" && (
            <Button size="sm" onClick={() => { onEnroll(user); onClose(); }} variant="outline" className="gap-1.5 text-xs">
              <GradCap className="w-3.5 h-3.5" /> Enroll Course
            </Button>
          )}
          {user.role !== "super_admin" && (user.isActive ? (
            <Button size="sm" onClick={() => { onDeactivate(user.id); onClose(); }}
              className="gap-1.5 text-xs text-orange-600 border-orange-200 bg-orange-50 hover:bg-orange-100" variant="outline">
              <UserX className="w-3.5 h-3.5" /> Deactivate
            </Button>
          ) : (
            <Button size="sm" onClick={() => { onReactivate(user.id); onClose(); }}
              className="gap-1.5 text-xs text-green-600 border-green-200 bg-green-50 hover:bg-green-100" variant="outline">
              <UserCheck2 className="w-3.5 h-3.5" /> Reactivate
            </Button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Password Reset Modal ─────────────────────────────────────────────────────
function PasswordResetModal({ user, onClose, flash }: {
  user: User;
  onClose: () => void;
  flash: (msg: string, ok?: boolean) => void;
}) {
  const [pw, setPw] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [busy, setBusy] = useState(false);
  const strength = passwordStrength(pw);
  const match = pw === confirm;

  async function doReset() {
    if (!pw || !match) return;
    setBusy(true);
    const r = await apiFetch(`/admin/users/${user.id}/reset-password`, {
      method: "POST",
      body: JSON.stringify({ password: pw }),
    });
    setBusy(false);
    if (r.ok) { flash(`Password reset for ${user.name}!`); onClose(); }
    else { const d = await r.json(); flash(d.error ?? "Failed", false); }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-bold text-sm" style={{ color: NAVY }}>Reset Password</h3>
            <p className="text-xs text-gray-400 mt-0.5">For: <span className="font-semibold">{user.name}</span></p>
          </div>
          <button onClick={onClose}><X className="w-5 h-5 text-gray-400" /></button>
        </div>

        <div className="space-y-2">
          <div className="relative">
            <Input
              type={showPw ? "text" : "password"}
              placeholder="New password *"
              value={pw}
              onChange={e => setPw(e.target.value)}
              className="pr-20"
            />
            <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
              <button type="button" onClick={() => setShowPw(p => !p)} className="text-gray-400 hover:text-gray-600 p-1">
                {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
              {pw && (
                <button type="button" onClick={() => { navigator.clipboard.writeText(pw); flash("Copied!"); }} className="text-gray-400 hover:text-gray-600 p-1">
                  <Copy className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          {pw && (
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-gray-400">Strength</span>
                <span className="font-semibold" style={{ color: strength.color }}>{strength.label}</span>
              </div>
              <div className="h-1.5 rounded-full bg-gray-100">
                <div className="h-1.5 rounded-full transition-all" style={{ background: strength.color, width: `${(strength.score / 5) * 100}%` }} />
              </div>
            </div>
          )}

          <Input
            type={showPw ? "text" : "password"}
            placeholder="Confirm password *"
            value={confirm}
            onChange={e => setConfirm(e.target.value)}
            className={confirm && !match ? "border-red-300 focus:ring-red-400" : ""}
          />
          {confirm && !match && <p className="text-xs text-red-500">Passwords do not match</p>}

          <button
            type="button"
            onClick={() => { const p = generatePassword(); setPw(p); setConfirm(p); }}
            className="flex items-center gap-1.5 text-xs text-orange-500 hover:text-orange-700 font-medium">
            <RefreshCw className="w-3.5 h-3.5" /> Auto-generate strong password
          </button>
        </div>

        <div className="flex gap-2 pt-1">
          <Button size="sm" onClick={doReset} disabled={busy || !pw || !match || pw.length < 6}
            className="text-white flex-1" style={{ background: ORANGE }}>
            {busy ? "Resetting…" : "Reset Password"}
          </Button>
          <Button size="sm" variant="ghost" onClick={onClose}>Cancel</Button>
        </div>
      </div>
    </div>
  );
}

// ── Skeleton Loader ──────────────────────────────────────────────────────────
function SkeletonRow() {
  return (
    <tr className="border-b border-gray-50">
      {[1, 2, 3, 4, 5].map(i => (
        <td key={i} className="px-4 py-3">
          <div className="h-4 rounded-full bg-gray-100 animate-pulse" style={{ width: `${[60, 80, 40, 30, 20][i - 1]}%` }} />
        </td>
      ))}
    </tr>
  );
}

// ── Placeholder Tab ──────────────────────────────────────────────────────────
function ModulePage({ icon: Icon, title, description, roadmap, emoji = "🚧", statusLabel = "Coming Soon", statusColor = "orange" }: {
  icon: React.ElementType;
  title: string;
  description: string;
  emoji?: string;
  statusLabel?: string;
  statusColor?: "orange" | "purple" | "blue";
  roadmap: { phase: string; items: string[] }[];
}) {
  const colorMap = {
    orange: { bg: "bg-orange-100", text: "text-orange-600", dot: ORANGE, cardBg: `${ORANGE}15` },
    purple: { bg: "bg-purple-100", text: "text-purple-700", dot: "#8B5CF6", cardBg: "#8B5CF615" },
    blue:   { bg: "bg-blue-100",   text: "text-blue-700",   dot: "#3B82F6", cardBg: "#3B82F615" },
  };
  const c = colorMap[statusColor];
  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0" style={{ background: c.cardBg }}>
              <Icon className="w-6 h-6" style={{ color: c.dot }} />
            </div>
            <div>
              <h2 className="text-lg font-black" style={{ color: NAVY }}>{title}</h2>
              <p className="text-sm text-gray-400 mt-0.5">{description}</p>
            </div>
          </div>
          <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full flex-shrink-0 ${c.bg} ${c.text}`}>{statusLabel}</span>
        </div>
      </div>

      {/* Status card */}
      <div className="bg-white rounded-2xl p-8 border border-gray-100 shadow-sm flex flex-col items-center gap-3">
        <div className="w-20 h-20 rounded-3xl flex items-center justify-center text-4xl" style={{ background: `${NAVY}08` }}>{emoji}</div>
        <div className="text-center">
          <p className="font-black text-base" style={{ color: NAVY }}>This module is under construction</p>
          <p className="text-sm text-gray-400 mt-1 max-w-sm">
            {title} is being developed for an upcoming sprint. The data model and API contracts are already being designed.
          </p>
        </div>
        <div className={`flex items-center gap-2 px-4 py-1.5 rounded-full border ${c.bg} ${c.text}`} style={{ borderColor: `${c.dot}30` }}>
          <Clock className="w-3.5 h-3.5" />
          <span className="text-xs font-semibold">Planned for upcoming sprint</span>
        </div>
      </div>

      {/* Roadmap */}
      <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
        <h3 className="font-bold text-sm mb-4 flex items-center gap-2" style={{ color: NAVY }}>
          <TrendingUp className="w-4 h-4" style={{ color: ORANGE }} /> Planned Features
        </h3>
        <div className="space-y-4">
          {roadmap.map((phase, pi) => (
            <div key={pi} className="flex gap-4">
              <div className="flex flex-col items-center">
                <div className="w-7 h-7 rounded-full flex items-center justify-center text-[10px] font-black text-white flex-shrink-0" style={{ background: pi === 0 ? c.dot : "#CBD5E1" }}>
                  {pi + 1}
                </div>
                {pi < roadmap.length - 1 && <div className="w-px flex-1 mt-1" style={{ background: "#E2E8F0" }} />}
              </div>
              <div className="pb-4">
                <p className="text-[11px] font-black uppercase tracking-widest mb-2" style={{ color: pi === 0 ? c.dot : "#94A3B8" }}>{phase.phase}</p>
                <ul className="space-y-1.5">
                  {phase.items.map(item => (
                    <li key={item} className="flex items-center gap-2 text-xs text-gray-600">
                      <div className="w-1 h-1 rounded-full flex-shrink-0" style={{ background: pi === 0 ? c.dot : "#CBD5E1" }} />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Access Management Modal ───────────────────────────────────────────────────
function AccessModal({ user, onClose, flash }: {
  user: User;
  onClose: () => void;
  flash: (msg: string, ok?: boolean) => void;
}) {
  type CourseRow = { id: number; title: string; grade: number; subjectName: string; enrolled: boolean; enrollmentId: number | null };
  const [courses, setCourses] = useState<CourseRow[]>([]);
  const [grade, setGrade] = useState(String(user.grade > 0 ? user.grade : ""));
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [savingGrade, setSavingGrade] = useState(false);
  const [toggling, setToggling] = useState<number | null>(null);

  useEffect(() => {
    apiFetch(`/admin/users/${user.id}/courses`)
      .then(r => r.json())
      .then((data: CourseRow[]) => { setCourses(data); setLoading(false); })
      .catch(() => setLoading(false));
  }, [user.id]);

  const saveGrade = async () => {
    if (!grade) return;
    setSavingGrade(true);
    const r = await apiFetch(`/admin/users/${user.id}`, {
      method: "PATCH",
      body: JSON.stringify({ grade: Number(grade) }),
    });
    setSavingGrade(false);
    if (r.ok) flash("Grade updated successfully");
    else flash("Failed to update grade", false);
  };

  const toggleEnroll = async (course: CourseRow) => {
    setToggling(course.id);
    if (course.enrolled && course.enrollmentId) {
      const r = await apiFetch(`/admin/enrollments/${course.enrollmentId}`, { method: "DELETE" });
      if (r.ok) {
        setCourses(prev => prev.map(c => c.id === course.id ? { ...c, enrolled: false, enrollmentId: null } : c));
        flash(`Removed access to "${course.title}"`);
      } else flash("Failed to remove access", false);
    } else {
      const r = await apiFetch("/admin/enrollments", {
        method: "POST",
        body: JSON.stringify({ studentId: user.id, courseId: course.id }),
      });
      if (r.ok) {
        const data = await r.json();
        setCourses(prev => prev.map(c => c.id === course.id ? { ...c, enrolled: true, enrollmentId: data.id } : c));
        flash(`Access granted to "${course.title}"`);
      } else flash("Failed to grant access", false);
    }
    setToggling(null);
  };

  const filtered = courses.filter(c =>
    c.title.toLowerCase().includes(search.toLowerCase()) ||
    c.subjectName.toLowerCase().includes(search.toLowerCase())
  );
  const enrolledCount = courses.filter(c => c.enrolled).length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(0,0,0,0.45)" }}>
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg flex flex-col" style={{ maxHeight: "85vh" }}>
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full flex items-center justify-center text-white text-sm font-bold" style={{ background: NAVY }}>
              {user.name[0]?.toUpperCase()}
            </div>
            <div>
              <div className="font-bold text-sm" style={{ color: NAVY }}>Manage Access — {user.name}</div>
              <div className="text-xs text-gray-400">{user.email ?? user.phone ?? `ID ${user.id}`}</div>
            </div>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition-colors p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {/* Grade */}
          <div className="bg-blue-50 rounded-xl p-4 flex items-center gap-3">
            <GraduationCap className="w-4 h-4 shrink-0" style={{ color: NAVY }} />
            <span className="text-xs font-semibold text-gray-600 shrink-0">Grade</span>
            <select
              value={grade}
              onChange={e => setGrade(e.target.value)}
              className="flex-1 text-sm border border-gray-200 rounded-lg px-2 py-1.5 bg-white focus:outline-none"
            >
              <option value="">Not assigned</option>
              {[1,2,3,4,5,6,7,8,9,10].map(g => (
                <option key={g} value={g}>Grade {g}</option>
              ))}
            </select>
            <Button size="sm" onClick={saveGrade} disabled={savingGrade || !grade}
              className="text-white text-xs shrink-0" style={{ background: NAVY }}>
              {savingGrade ? "Saving…" : "Save"}
            </Button>
          </div>

          {/* Course access */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold" style={{ color: NAVY }}>Course Access</span>
              <span className="text-xs text-gray-400">{enrolledCount} of {courses.length} granted</span>
            </div>
            <div className="relative mb-3">
              <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <Input
                placeholder="Search courses or subjects…"
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="pl-9 text-xs h-9"
              />
            </div>
            {loading ? (
              <div className="text-center py-8 text-gray-400 text-xs">Loading courses…</div>
            ) : filtered.length === 0 ? (
              <div className="text-center py-8 text-gray-400 text-xs">No courses found</div>
            ) : (
              <div className="space-y-1.5">
                {filtered.map(c => (
                  <div key={c.id}
                    className={`flex items-center justify-between px-3 py-2.5 rounded-xl border transition-colors ${
                      c.enrolled ? "bg-green-50 border-green-100" : "bg-gray-50 border-transparent"
                    }`}
                  >
                    <div className="min-w-0 mr-3">
                      <div className="text-xs font-semibold truncate" style={{ color: NAVY }}>{c.title}</div>
                      <div className="text-[10px] text-gray-400 mt-0.5">{c.subjectName} · Grade {c.grade}</div>
                    </div>
                    <button
                      onClick={() => toggleEnroll(c)}
                      disabled={toggling === c.id}
                      className={`shrink-0 text-xs px-3 py-1.5 rounded-lg font-semibold transition-colors ${
                        c.enrolled
                          ? "bg-white border border-red-200 text-red-500 hover:bg-red-50"
                          : "text-white hover:opacity-90"
                      }`}
                      style={c.enrolled ? {} : { background: ORANGE }}
                    >
                      {toggling === c.id ? "…" : c.enrolled ? "Remove" : "Grant"}
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="px-5 py-3 border-t border-gray-100 shrink-0 flex justify-end">
          <Button size="sm" variant="ghost" onClick={onClose} className="text-xs">Done</Button>
        </div>
      </div>
    </div>
  );
}

// ── Main Component ───────────────────────────────────────────────────────────
function AdminPageInner() {
  const { student, role, isLoading, logout } = useAuth();
  const [tab, setTab] = useState<Tab>("dashboard");

  // Data
  const [stats, setStats] = useState<Stats | null>(null);
  const [analytics, setAnalytics] = useState<Analytics | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [mentorStudentMap, setMentorStudentMap] = useState<Record<number, { mentorName: string; mentorPhone: string | null }>>({});
  const [courses, setCourses] = useState<Course[]>([]);
  const [assignments, setAssignments] = useState<TeacherAssignment[]>([]);
  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [banners, setBanners] = useState<Banner[]>([]);
  const [liveClassItems, setLiveClassItems] = useState<LiveClassItem[]>([]);
  const [subjectsList, setSubjectsList] = useState<{ id: number; name: string }[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [dataLoading, setDataLoading] = useState(false);

  // UI state
  const [userSubTab, setUserSubTab] = useState<UserSubTab>("active");
  const [searchQuery, setSearchQuery] = useState("");
  const [gradeFilter, setGradeFilter] = useState("all");
  const [roleFilter, setRoleFilter] = useState("all");
  const [courseFilter, setCourseFilter] = useState("all");
  const [showFilters, setShowFilters] = useState(false);
  const [sortField, setSortField] = useState<SortField>("name");
  const [sortDir, setSortDir] = useState<SortDir>("asc");
  const [page, setPage] = useState(1);
  const PAGE_SIZE = 20;

  // Bulk selection
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());

  // Modals
  const [confirmDialog, setConfirmDialog] = useState<ConfirmDialog | null>(null);
  const [profileUser, setProfileUser] = useState<User | null>(null);
  const [accessUser, setAccessUser] = useState<User | null>(null);
  const [resetPasswordUser, setResetPasswordUser] = useState<User | null>(null);
  const [student360Id, setStudent360Id] = useState<number | null>(null);

  // Forms
  const [showCreateUser, setShowCreateUser] = useState(false);
  const [showAssignTeacher, setShowAssignTeacher] = useState(false);
  const [showEnrollStudent, setShowEnrollStudent] = useState(false);
  const [showAnnForm, setShowAnnForm] = useState(false);
  const [showBannerForm, setShowBannerForm] = useState(false);
  const [showLcForm, setShowLcForm] = useState(false);
  const [editingLcFull, setEditingLcFull] = useState<{ id: number; title: string; teacher: string; grade: string; scheduledAt: string; duration: string } | null>(null);
  const [auditSearch, setAuditSearch] = useState("");
  const [auditRoleFilter, setAuditRoleFilter] = useState("all");

  // Analytics filters
  const [analyticsGradeFilter, setAnalyticsGradeFilter] = useState("all");
  const [analyticsUserTypeFilter, setAnalyticsUserTypeFilter] = useState("all");
  const [analyticsSearch, setAnalyticsSearch] = useState("");
  const [analyticsYearFilter, setAnalyticsYearFilter] = useState("all");

  // Academic years (for analytics + other filters)
  const [academicYearsList, setAcademicYearsList] = useState<AcademicYear[]>([]);

  // User row expansion
  const [expandedUserId, setExpandedUserId] = useState<number | null>(null);
  const [expandedUserData, setExpandedUserData] = useState<Record<number, { id: number; title: string; grade: number; enrolled: boolean; enrollmentId: number | null }[]>>({});
  const [inlineEditUserId, setInlineEditUserId] = useState<number | null>(null);
  const [inlineEditForm, setInlineEditForm] = useState({ name: "", grade: "", school: "", email: "" });

  // Live class cascade: Course → Subject → Chapter → Topic
  const [lcCourseSubjects, setLcCourseSubjects] = useState<{ id: number; name: string; subjectCode: string }[]>([]);
  const [lcChapters, setLcChapters] = useState<{ id: number; name: string; chapterCode: string }[]>([]);
  const [lcTopics, setLcTopics] = useState<{ id: number; name: string; topicCode: string }[]>([]);

  const [newUser, setNewUser] = useState({ name: "", email: "", phone: "", password: "", confirmPassword: "", role: "student" as Role, grade: "6", school: "" });
  const [showNewPw, setShowNewPw] = useState(false);
  const [assignForm, setAssignForm] = useState({ teacherId: "", courseId: "", courseSubjectId: "" });
  const [assignCourseSubjects, setAssignCourseSubjects] = useState<{ id: number; name: string }[]>([]);
  const [enrollForm, setEnrollForm] = useState({ studentId: "", courseId: "" });
  const [annForm, setAnnForm] = useState({ title: "", body: "", grade: "", targetRole: "all" });
  const [bannerForm, setBannerForm] = useState({ title: "", imageUrl: "", link: "", displayOrder: "0" });
  const [lcForm, setLcForm] = useState({ title: "", courseId: "", courseSubjectId: "", chapterId: "", topicId: "", grade: "", teacherId: "", teacher: "", scheduledAt: "", duration: "60", joinUrl: "" });

  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ text: string; ok: boolean } | null>(null);

  // Profile dropdown + check-in state
  const [profileDropOpen, setProfileDropOpen] = useState(false);
  const [todayCheckin, setTodayCheckin] = useState<{ checkInTime: string | null; checkOutTime: string | null } | null | undefined>(undefined);
  const [checkingIn, setCheckingIn] = useState(false);
  const profileDropRef = useRef<HTMLDivElement>(null);

  const debouncedSearch = useDebounce(searchQuery, 300);

  const teachers = useMemo(() => users.filter(u => u.role === "teacher"), [users]);
  const activeTeachers = useMemo(() => teachers.filter(t => t.isActive), [teachers]);
  const students = useMemo(() => users.filter(isMasteryStudent), [users]);

  useEffect(() => { if (!isLoading && (role === "admin" || role === "super_admin")) loadAll(); }, [isLoading, role]);

  // Load today's check-in status
  useEffect(() => {
    apiFetch("/staff/checkin/today").then(r => r.ok ? r.json() : null).then(setTodayCheckin).catch(() => setTodayCheckin(null));
  }, []);

  // Live clock (IST)
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  // Bell / notifications dropdown
  const [bellDropOpen, setBellDropOpen] = useState(false);
  const bellDropRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!bellDropOpen) return;
    function handler(e: MouseEvent) {
      if (bellDropRef.current && !bellDropRef.current.contains(e.target as Node)) setBellDropOpen(false);
    }
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [bellDropOpen]);

  // Close profile dropdown on outside click
  useEffect(() => {
    if (!profileDropOpen) return;
    function handler(e: MouseEvent) {
      if (profileDropRef.current && !profileDropRef.current.contains(e.target as Node)) setProfileDropOpen(false);
    }
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [profileDropOpen]);

  // Export report as CSV
  function exportReport() {
    if (!stats) { flash("Load dashboard data first", false); return; }
    const rows: (string | number)[][] = [
      ["Braintam Report", new Date().toLocaleString("en-IN", { timeZone: "Asia/Kolkata" })],
      [],
      ["Metric", "Value"],
      ["Total Users", stats.totalUsers],
      ["Students", stats.totalStudents],
      ["Teachers", stats.totalTeachers],
      ["Courses", stats.totalCourses],
      ["Enrollments", stats.totalEnrollments],
      ["Teacher Assignments", stats.totalTeacherAssignments],
    ];
    const csv = rows.map(r => r.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `braintam-report-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a); a.click();
    document.body.removeChild(a); URL.revokeObjectURL(url);
    flash("Report exported ✓", true);
  }

  async function loadAll() {
    setDataLoading(true);
    const [s, u, c, a, e, anns, bans, ana, lcs, subjs, audit, yrs, mentorMap] = await Promise.all([
      apiFetch("/admin/stats").then(r => r.ok ? r.json() : null),
      apiFetch("/admin/users").then(r => r.ok ? r.json() : []),
      apiFetch("/admin/courses").then(r => r.ok ? r.json() : []),
      apiFetch("/admin/teacher-courses").then(r => r.ok ? r.json() : []),
      apiFetch("/admin/enrollments").then(r => r.ok ? r.json() : []),
      apiFetch("/admin/announcements").then(r => r.ok ? r.json() : []),
      apiFetch("/admin/banners").then(r => r.ok ? r.json() : []),
      apiFetch("/admin/analytics").then(r => r.ok ? r.json() : null),
      apiFetch("/admin/live-classes").then(r => r.ok ? r.json() : []),
      apiFetch("/subjects").then(r => r.ok ? r.json() : []),
      apiFetch("/admin/audit-logs").then(async r => { if (!r.ok) return []; const d = await r.json(); return Array.isArray(d) ? d : (d.logs ?? []); }),
      apiFetch("/admin/academic-years").then(r => r.ok ? r.json() : []),
      apiFetch("/admin/mentor-student-map").then(r => r.ok ? r.json() : []),
    ]);
    setStats(s); setUsers(u); setCourses(c); setAssignments(a); setEnrollments(e);
    setAnnouncements(anns); setBanners(bans); setAnalytics(ana); setLiveClassItems(lcs);
    setSubjectsList(subjs); setAuditLogs(audit); setAcademicYearsList(Array.isArray(yrs) ? yrs : []);
    const mMap: Record<number, { mentorName: string; mentorPhone: string | null }> = {};
    for (const row of (mentorMap as { studentId: number; mentorName: string; mentorPhone: string | null }[])) {
      mMap[row.studentId] = { mentorName: row.mentorName, mentorPhone: row.mentorPhone };
    }
    setMentorStudentMap(mMap);
    setDataLoading(false);
  }

  async function toggleUserExpand(userId: number) {
    if (expandedUserId === userId) { setExpandedUserId(null); return; }
    setExpandedUserId(userId);
    // Always re-fetch so enrollment changes are reflected immediately
    setExpandedUserData(prev => ({ ...prev, [userId]: undefined as any }));
    const data = await apiFetch(`/admin/users/${userId}/courses`).then(r => r.ok ? r.json() : []);
    setExpandedUserData(prev => ({ ...prev, [userId]: Array.isArray(data) ? data : [] }));
  }

  const flash = useCallback((text: string, ok = true) => { setMsg({ text, ok }); setTimeout(() => setMsg(null), 3500); }, []);

  async function doCheckIn() {
    setCheckingIn(true);
    try {
      const r = await apiFetch("/staff/checkin", { method: "POST" });
      if (r.ok) {
        setTodayCheckin(await r.json());
        flash("Checked in successfully!");
      }
    } finally {
      setCheckingIn(false);
    }
  }

  async function doCheckOut() {
    try {
      const r = await apiFetch("/staff/checkin/checkout", {
        method: "PATCH",
        body: JSON.stringify({}),
      });

      if (r.ok) {
        setTodayCheckin(await r.json());
        flash("Checked out successfully!");
      } else {
        flash("Checkout failed", false);
      }
    } catch {
      flash("Checkout failed", false);
    }
  }

  function confirm(dialog: ConfirmDialog) {
    setConfirmDialog(dialog);
    }
  // ── Filtered + Sorted Users ─────────────────────────────────────────────
  const filteredUsers = useMemo(() => {
    let list = users.filter(isMasteryStudent);

    if (userSubTab === "active") list = list.filter(u => u.isActive);
    else if (userSubTab === "deactivated") list = list.filter(u => !u.isActive);

    if (gradeFilter !== "all") list = list.filter(u => String(u.grade) === gradeFilter);

    if (courseFilter !== "all") {
      const enrolled = new Set(enrollments.filter(e => String(e.courseId) === courseFilter).map(e => e.studentId));
      list = list.filter(u => enrolled.has(u.id));
    }

    if (debouncedSearch) {
      const q = debouncedSearch.toLowerCase();
      list = list.filter(u =>
        u.name.toLowerCase().includes(q) ||
        (u.email ?? "").toLowerCase().includes(q) ||
        (u.phone ?? "").includes(q) ||
        String(u.id).includes(q) ||
        (u.school ?? "").toLowerCase().includes(q)
      );
    }

    list = [...list].sort((a, b) => {
      let va: string | number = a[sortField] ?? "";
      let vb: string | number = b[sortField] ?? "";
      if (typeof va === "string") va = va.toLowerCase();
      if (typeof vb === "string") vb = vb.toLowerCase();
      const cmp = va < vb ? -1 : va > vb ? 1 : 0;
      return sortDir === "asc" ? cmp : -cmp;
    });

    return list;
  }, [users, userSubTab, gradeFilter, courseFilter, enrollments, debouncedSearch, sortField, sortDir]);

  const totalPages = Math.ceil(filteredUsers.length / PAGE_SIZE);
  const pagedUsers = filteredUsers.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  function toggleSort(field: SortField) {
    if (sortField === field) setSortDir(d => d === "asc" ? "desc" : "asc");
    else { setSortField(field); setSortDir("asc"); }
    setPage(1);
  }

  function SortIcon({ field }: { field: SortField }) {
    if (sortField !== field) return <ChevronDown className="w-3 h-3 text-gray-300" />;
    return sortDir === "asc" ? <ChevronUp className="w-3 h-3 text-gray-500" /> : <ChevronDown className="w-3 h-3 text-gray-500" />;
  }

  // Bulk helpers
  const allPageSelected = pagedUsers.length > 0 && pagedUsers.every(u => selectedIds.has(u.id));
  function toggleSelectAll() {
    const newSet = new Set(selectedIds);
    if (allPageSelected) pagedUsers.forEach(u => newSet.delete(u.id));
    else pagedUsers.forEach(u => newSet.add(u.id));
    setSelectedIds(newSet);
  }
  function toggleSelect(id: number) {
    const newSet = new Set(selectedIds);
    if (newSet.has(id)) newSet.delete(id); else newSet.add(id);
    setSelectedIds(newSet);
  }

  if (isLoading) return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: "#F5F7FF" }}>
      <div className="animate-spin rounded-full h-10 w-10 border-4 border-orange-500 border-t-transparent" />
    </div>
  );
  if (!student) return <Redirect to="/sign-in" />;
  if (role !== "admin" && role !== "super_admin") return <Redirect to="/dashboard" />;

  // ── Actions ──────────────────────────────────────────────────────────────
  async function createUser() {
    if (newUser.password !== newUser.confirmPassword) { flash("Passwords do not match", false); return; }
    setBusy(true);
    const { confirmPassword: _, ...payload } = newUser;
    const r = await apiFetch("/admin/users", {
      method: "POST",
      body: JSON.stringify({ ...payload, grade: Number(newUser.grade) }),
    });
    if (r.ok) {
      flash("User created!");
      setShowCreateUser(false);
      setNewUser({ name: "", email: "", phone: "", password: "", confirmPassword: "", role: "student", grade: "6", school: "" });
      loadAll();
    } else { const d = await r.json(); flash(d.error ?? "Error", false); }
    setBusy(false);
  }

  async function deactivateUser(id: number) {
    await apiFetch(`/admin/users/${id}`, { method: "PATCH", body: JSON.stringify({ isActive: false }) });
    flash("User deactivated"); loadAll();
  }

  async function reactivateUser(id: number) {
    await apiFetch(`/admin/users/${id}`, { method: "PATCH", body: JSON.stringify({ isActive: true }) });
    flash("User reactivated"); loadAll();
  }

  async function permanentDeleteUser(id: number) {
    await apiFetch(`/admin/users/${id}`, { method: "DELETE" });
    flash("User permanently deleted"); loadAll();
  }

  async function saveInlineEdit(userId: number) {
    const { name, grade, school, email } = inlineEditForm;
    if (!name.trim()) { flash("Name is required", false); return; }
    setBusy(true);
    try {
      const body: Record<string, unknown> = { name: name.trim(), school: school.trim() || null, email: email.trim() || null };
      const gradeNum = Number(grade);
      if (!isNaN(gradeNum) && gradeNum >= 0) body.grade = gradeNum;
      const r = await apiFetch(`/admin/users/${userId}`, { method: "PATCH", body: JSON.stringify(body) });
      if (!r.ok) { flash("Failed to update user", false); return; }
      const updated = await r.json();
      setUsers(prev => prev.map(u => u.id === userId ? { ...u, ...updated } : u));
      setInlineEditUserId(null);
      flash("User updated");
    } finally { setBusy(false); }
  }

  async function bulkDeactivate() {
    const ids = [...selectedIds];
    await Promise.all(ids.map(id => apiFetch(`/admin/users/${id}`, { method: "PATCH", body: JSON.stringify({ isActive: false }) })));
    flash(`${ids.length} users deactivated`); setSelectedIds(new Set()); loadAll();
  }

  function exportUsersCSV() {
    exportCSV("braintam_users.csv",
      ["ID", "Name", "Email", "Phone", "Role", "Grade", "School", "Active"],
      filteredUsers.map(u => [u.id, u.name, u.email, u.phone, u.role, u.grade, u.school, u.isActive ? "Yes" : "No"])
    );
  }

  function exportEnrollmentsCSV() {
    exportCSV("braintam_enrollments.csv",
      ["ID", "Student", "Course", "Enrolled At"],
      enrollments.map(e => [e.id, e.studentName, e.courseTitle, e.enrolledAt])
    );
  }

  async function loadSubjectsForAssign(courseId: string) {
    if (!courseId) { setAssignCourseSubjects([]); return; }
    const r = await apiFetch(`/admin/course-subjects?courseId=${courseId}`);
    setAssignCourseSubjects(r.ok ? await r.json() : []);
  }

  async function assignTeacher() {
    setBusy(true);
    const r = await apiFetch("/admin/teacher-courses", {
      method: "POST",
      body: JSON.stringify({
        teacherId: Number(assignForm.teacherId),
        courseId: Number(assignForm.courseId),
        courseSubjectId: assignForm.courseSubjectId ? Number(assignForm.courseSubjectId) : null,
      }),
    });
    if (r.ok) {
      flash("Teacher assigned!");
      setShowAssignTeacher(false);
      setAssignForm({ teacherId: "", courseId: "", courseSubjectId: "" });
      setAssignCourseSubjects([]);
      loadAll();
    } else { const d = await r.json(); flash(d.error ?? "Error", false); }
    setBusy(false);
  }

  async function removeAssignment(id: number) { await apiFetch(`/admin/teacher-courses/${id}`, { method: "DELETE" }); loadAll(); }

  async function enrollStudent() {
    setBusy(true);
    const studentId = Number(enrollForm.studentId);
    const r = await apiFetch("/admin/enrollments", {
      method: "POST",
      body: JSON.stringify({ studentId, courseId: Number(enrollForm.courseId) }),
    });
    if (r.ok) {
      flash("Student enrolled!");
      setShowEnrollStudent(false);
      setEnrollForm({ studentId: "", courseId: "" });
      // Invalidate cached course list for this student so expanded row refreshes
      setExpandedUserData(prev => { const next = { ...prev }; delete next[studentId]; return next; });
      loadAll();
    } else { const d = await r.json(); flash(d.error ?? "Error", false); }
    setBusy(false);
  }

  async function removeEnrollment(enrollmentId: number, studentId?: number) {
    await apiFetch(`/admin/enrollments/${enrollmentId}`, { method: "DELETE" });
    // Invalidate cached course list for this student
    if (studentId) setExpandedUserData(prev => { const next = { ...prev }; delete next[studentId]; return next; });
    loadAll();
  }

  async function createAnnouncement() {
    setBusy(true);
    const r = await apiFetch("/admin/announcements", {
      method: "POST",
      body: JSON.stringify({ title: annForm.title, body: annForm.body, grade: annForm.grade ? Number(annForm.grade) : null, targetRole: annForm.targetRole }),
    });
    if (r.ok) { flash("Announcement published!"); setShowAnnForm(false); setAnnForm({ title: "", body: "", grade: "", targetRole: "all" }); loadAll(); }
    else { const d = await r.json(); flash(d.error ?? "Error", false); }
    setBusy(false);
  }

  async function deleteAnnouncement(id: number) { await apiFetch(`/admin/announcements/${id}`, { method: "DELETE" }); loadAll(); }
  async function toggleAnnouncement(ann: Announcement) { await apiFetch(`/admin/announcements/${ann.id}`, { method: "PATCH", body: JSON.stringify({ isActive: !ann.isActive }) }); loadAll(); }

  async function createBanner() {
    setBusy(true);
    const r = await apiFetch("/admin/banners", {
      method: "POST",
      body: JSON.stringify({ title: bannerForm.title, imageUrl: bannerForm.imageUrl, link: bannerForm.link || null, displayOrder: Number(bannerForm.displayOrder) }),
    });
    if (r.ok) { flash("Banner created!"); setShowBannerForm(false); setBannerForm({ title: "", imageUrl: "", link: "", displayOrder: "0" }); loadAll(); }
    else { const d = await r.json(); flash(d.error ?? "Error", false); }
    setBusy(false);
  }

  async function deleteBanner(id: number) { await apiFetch(`/admin/banners/${id}`, { method: "DELETE" }); loadAll(); }
  async function toggleBanner(banner: Banner) { await apiFetch(`/admin/banners/${banner.id}`, { method: "PATCH", body: JSON.stringify({ isActive: !banner.isActive }) }); loadAll(); }

  async function loadSubjectsForCourse(courseId: string) {
    if (!courseId) { setLcCourseSubjects([]); setLcChapters([]); setLcTopics([]); return; }
    const r = await apiFetch(`/admin/course-subjects?courseId=${courseId}`);
    if (r.ok) setLcCourseSubjects(await r.json());
    else setLcCourseSubjects([]);
  }

  async function loadChaptersForSubject(courseSubjectId: string) {
    if (!courseSubjectId) { setLcChapters([]); setLcTopics([]); return; }
    const r = await apiFetch(`/admin/chapters?courseSubjectId=${courseSubjectId}`);
    if (r.ok) setLcChapters(await r.json());
    else setLcChapters([]);
  }

  async function loadTopicsForChapter(chapterId: string) {
    if (!chapterId || chapterId === "") { setLcTopics([]); return; }
    const r = await apiFetch(`/admin/topics?chapterId=${chapterId}`);
    if (r.ok) setLcTopics(await r.json());
  }

  async function createLiveClass() {
    setBusy(true);
    const hasTeacher = lcForm.teacherId && lcForm.teacherId !== "none";
    const teacherName = hasTeacher
      ? (teachers.find(t => String(t.id) === lcForm.teacherId)?.name ?? lcForm.teacher)
      : (lcForm.teacher || "To be assigned");
    const selectedCourseForLc = lcForm.courseId ? courses.find(c => String(c.id) === lcForm.courseId) : null;
    const r = await apiFetch("/admin/live-classes", {
      method: "POST",
      body: JSON.stringify({
        title: lcForm.title,
        courseId: lcForm.courseId ? Number(lcForm.courseId) : null,
        courseSubjectId: lcForm.courseSubjectId ? Number(lcForm.courseSubjectId) : null,
        chapterId: lcForm.chapterId ? Number(lcForm.chapterId) : null,
        topicId: lcForm.topicId ? Number(lcForm.topicId) : null,
        grade: lcForm.grade ? Number(lcForm.grade) : (selectedCourseForLc?.grade ?? null),
        teacherId: hasTeacher ? Number(lcForm.teacherId) : null,
        teacher: teacherName,
        scheduledAt: new Date(lcForm.scheduledAt + ":00+05:30").toISOString(),
        duration: Number(lcForm.duration),
        joinUrl: lcForm.joinUrl || null,
      }),
    });
    if (r.ok) {
      flash("Live class scheduled!");
      setShowLcForm(false);
      setLcForm({ title: "", courseId: "", courseSubjectId: "", chapterId: "", topicId: "", grade: "", teacherId: "", teacher: "", scheduledAt: "", duration: "60", joinUrl: "" });
      setLcCourseSubjects([]);
      setLcChapters([]);
      setLcTopics([]);
      loadAll();
    } else { const d = await r.json(); flash(d.error ?? "Error", false); }
    setBusy(false);
  }

  async function updateLiveClassStatus(id: number, status: string) {
    await apiFetch(`/admin/live-classes/${id}`, { method: "PATCH", body: JSON.stringify({ status }) }); loadAll();
  }

  async function updateLiveClassFull() {
    if (!editingLcFull) return;
    setBusy(true);
    const r = await apiFetch(`/admin/live-classes/${editingLcFull.id}`, {
      method: "PATCH",
      body: JSON.stringify({
        title: editingLcFull.title,
        teacher: editingLcFull.teacher,
        grade: Number(editingLcFull.grade),
        scheduledAt: new Date(editingLcFull.scheduledAt + ":00+05:30").toISOString(),
        duration: Number(editingLcFull.duration),
      }),
    });
    if (r.ok) { flash("Live class updated!"); setEditingLcFull(null); loadAll(); }
    else { const d = await r.json(); flash(d.error ?? "Failed to update", false); }
    setBusy(false);
  }

  async function deleteLiveClass(id: number) { await apiFetch(`/admin/live-classes/${id}`, { method: "DELETE" }); loadAll(); }

  const [igniteView, setIgniteView] = useState<IgniteView>("dashboard");
  const [openWorkspace, setOpenWorkspace] = useState<string>("ignite");
  const [openSections, setOpenSections] = useState<Record<string, boolean>>({
    "command-center:Analytics": true,
    "command-center:Administration": true,
  });

  type WorkspaceNavItem = {
    label: string;
    icon: React.ElementType;
    tab: Tab;
    igniteView?: IgniteView;
    superAdminOnly?: boolean;
  };
  type WorkspaceSection = {
    sectionLabel?: string;
    items: WorkspaceNavItem[];
  };
  const WORKSPACE_NAV: { id: string; emoji: string; label: string; sublabel: string; color: string; sections: WorkspaceSection[] }[] = [
    {
      id: "ignite", emoji: "🚀", label: "Ignite", sublabel: "Sales & Admissions", color: ORANGE,
      sections: [{
        items: [
          { label: "Dashboard", icon: LayoutDashboard, tab: "ignite", igniteView: "dashboard" },
          { label: "Leads", icon: Users, tab: "ignite", igniteView: "leads" },
          { label: "Demo Batches", icon: Layers, tab: "ignite", igniteView: "demo-batches" },
          { label: "Attendance Analytics", icon: CheckSquare, tab: "ignite", igniteView: "attendance" },
          { label: "Conversion Center", icon: TrendingUp, tab: "ignite", igniteView: "conversion" },
          { label: "Sales Mentors", icon: Award, tab: "ignite", igniteView: "sales-mentors" },
          { label: "Student Outreach", icon: UserCheck2, tab: "btl-crm" },
          { label: "Reports", icon: BarChart3, tab: "ignite", igniteView: "ignite-reports" },
        ],
      }],
    },
    {
      id: "mastery", emoji: "📚", label: "Mastery", sublabel: "Academic Operations", color: "#3B82F6",
      sections: [{
        items: [
          { label: "Dashboard", icon: Activity, tab: "dashboard" },
          { label: "Students", icon: Users, tab: "mastery-students" },
          { label: "Deployment", icon: Package, tab: "mastery-deployment" },
          { label: "Retention", icon: RotateCcw, tab: "mastery-retention" },
          { label: "Courses", icon: BookOpen, tab: "courses" },
          { label: "Live Classes", icon: Video, tab: "liveclasses" },
          { label: "Enrollments", icon: UserCheck, tab: "enrollments" },
          { label: "Mentors", icon: UserCheck2, tab: "mentors" },
          { label: "Assessments", icon: ClipboardList, tab: "assessments" },
          { label: "Announcements", icon: Bell, tab: "announcements" },
          { label: "Attendance Analytics", icon: CheckSquare, tab: "mastery-attendance" },
        ],
      }],
    },
    {
      id: "command-center", emoji: "🎯", label: "Command Center", sublabel: "Administration & Shared Resources", color: "#8B5CF6",
      sections: [
        {
          sectionLabel: "Analytics",
          items: [
            { label: "Course Analytics", icon: TrendingUp, tab: "course-analytics" },
            { label: "Teachers", icon: GradCap, tab: "teacher-analytics" },
            { label: "Mastery Analytics", icon: BarChart3, tab: "analytics" },
            { label: "Revenue Analytics", icon: DollarSign, tab: "revenue-analytics" },
            { label: "Reports & Analytics", icon: BarChart3, tab: "reports-analytics" },
            { label: "Learning Health", icon: AlertTriangle, tab: "health" },
          ],
        },
        {
          sectionLabel: "Administration",
          items: [
            { label: "Payments", icon: CreditCard, tab: "payments" },
            { label: "Course Assignments", icon: GradCap, tab: "assignments" },
            { label: "Gamification", icon: Zap, tab: "gamification" },
            { label: "Blocked Words", icon: Shield, tab: "blocked-words" },
            { label: "Command Center", icon: ShieldCheck, tab: "command-center" },
            { label: "Operations Center", icon: Cpu, tab: "operations-command-center" },
            { label: "Super Admin", icon: ShieldCheck, tab: "super-admin", superAdminOnly: true },
            { label: "Overview", icon: Activity, tab: "overview" },
            { label: "Audit Logs", icon: FileText, tab: "audit" },
            { label: "Staff Attendance", icon: CheckSquare, tab: "employee-attendance" },
            { label: "Banners", icon: Image, tab: "banners" },
            { label: "Settings", icon: Lock, tab: "settings" },
          ],
        },
      ],
    },
  ];

  const TABS: { id: Tab; label: string; icon: React.ElementType; group: string }[] = [
    { id: "dashboard", label: "Dashboard", icon: Activity, group: "Home" },
    { id: "analytics", label: "Analytics", icon: BarChart3, group: "Home" },
    { id: "course-analytics", label: "Course Analytics", icon: TrendingUp, group: "Insights" },
    { id: "teacher-analytics", label: "Teacher Analytics", icon: GradCap, group: "Insights" },
    { id: "health", label: "Learning Health", icon: AlertTriangle, group: "Insights" },
    { id: "gamification", label: "Gamification", icon: Zap, group: "Insights" },
    { id: "btl-crm", label: "BTL CRM", icon: UserCheck2, group: "Insights" },
    { id: "courses", label: "Courses", icon: BookOpen, group: "Content" },
    { id: "demo-batches", label: "Demo Batches", icon: Layers, group: "Content" },
    { id: "liveclasses", label: "Live Classes", icon: Video, group: "Content" },
    { id: "users", label: "Users", icon: Users, group: "Manage" },
    { id: "mentors", label: "Mentors", icon: UserCheck2, group: "Manage" },
    { id: "ignite", label: "🚀 Ignite CRM", icon: Zap, group: "Manage" },
    { id: "assignments", label: "Course Assignments", icon: LinkIcon, group: "Manage" },
    { id: "enrollments", label: "Enrollments", icon: UserCheck, group: "Manage" },
    { id: "announcements", label: "Announcements", icon: Bell, group: "Manage" },
    { id: "banners", label: "Banners", icon: Image, group: "Manage" },
    { id: "employee-attendance", label: "Staff Attendance", icon: CheckSquare, group: "Manage" },
    { id: "operations-command-center", label: "Operations Center", icon: Zap, group: "System" },
    { id: "super-admin", label: "Super Admin", icon: ShieldCheck, group: "System" },
    { id: "audit", label: "Audit Logs", icon: FileText, group: "System" },
    { id: "settings", label: "Settings", icon: Lock, group: "System" },
    { id: "overview", label: "Overview", icon: Activity, group: "System" },
    { id: "profile", label: "My Profile", icon: UserCircle, group: "System" },
  ].filter(t => t.id !== "super-admin" || role === "super_admin") as { id: Tab; label: string; icon: React.ElementType; group: string }[];
  const TAB_GROUPS = ["Home", "Insights", "Content", "Manage", "System"];

  return (
    <div className="h-screen flex flex-col overflow-hidden" style={{ background: "#F5F7FF", fontFamily: "Poppins, sans-serif" }}>
      {/* Confirm Dialog */}
      {confirmDialog && <ConfirmModal dialog={confirmDialog} onClose={() => setConfirmDialog(null)} />}
      {/* Profile Modal */}
      {profileUser && (
        <ProfileModal
          user={profileUser}
          flash={flash}
          onClose={() => setProfileUser(null)}
          onDeactivate={id => confirm({ title: "Deactivate User", message: `Deactivate ${profileUser.name}? They will lose access.`, confirmLabel: "Deactivate", danger: false, onConfirm: () => deactivateUser(id) })}
          onReactivate={id => reactivateUser(id)}
          onResetPassword={u => setResetPasswordUser(u)}
          onEnroll={u => { setEnrollForm(p => ({ ...p, studentId: String(u.id) })); setTab("enrollments"); setShowEnrollStudent(true); }}
        />
      )}
      {/* Password Reset Modal */}
      {resetPasswordUser && <PasswordResetModal user={resetPasswordUser} onClose={() => setResetPasswordUser(null)} flash={flash} />}
      {/* Access Management Modal */}
      {accessUser && <AccessModal user={accessUser} onClose={() => setAccessUser(null)} flash={flash} />}
      {/* ── Global Header ──────────────────────────────────────────────────────── */}
      <div className="h-14 shrink-0 bg-white border-b border-gray-200 flex items-center px-4 gap-3 z-30">
        <img src={braintamLogo} alt="Braintam" className="h-11 w-auto shrink-0" />
        <div className="flex items-center gap-1.5 pl-1">
          <div className="w-0.5 h-5 rounded-full flex-shrink-0" style={{ background: ORANGE }} />
          <div>
            <div className="font-black leading-tight" style={{ fontSize: "13px", color: NAVY, letterSpacing: "0.04em" }}>
              BTL <span style={{ color: ORANGE }}>CRM</span>
            </div>
            <div className="text-[9px] text-gray-400 leading-tight">Education Ops Platform</div>
          </div>
        </div>
        <div className="flex-1" />
        {/* Live date + IST clock */}
        <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border border-gray-200 text-xs shrink-0">
          <Calendar className="w-3 h-3 text-gray-400 shrink-0" />
          <span className="text-gray-500 whitespace-nowrap">
            {now.toLocaleDateString("en-IN", { day: "2-digit", month: "short", timeZone: "Asia/Kolkata" })}
          </span>
          <span className="font-mono font-semibold tabular-nums whitespace-nowrap" style={{ color: NAVY }}>
            {now.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", timeZone: "Asia/Kolkata", hour12: true })}
          </span>
        </div>
        {/* Refresh */}
        <button onClick={() => loadAll()} title="Refresh data"
          className="w-8 h-8 rounded-xl border border-gray-200 flex items-center justify-center hover:bg-gray-50 transition-colors shrink-0">
          <RotateCcw className={`w-4 h-4 text-gray-500 ${dataLoading ? "animate-spin" : ""}`} />
        </button>
        {/* Bell */}
        <div className="relative shrink-0" ref={bellDropRef}>
          <button onClick={() => setBellDropOpen(o => !o)}
            className="w-8 h-8 rounded-xl border border-gray-200 flex items-center justify-center hover:bg-gray-50 transition-colors">
            <Bell className="w-4 h-4 text-gray-500" />
          </button>
          {bellDropOpen && (
            <div className="absolute right-0 top-full mt-2 w-72 bg-white rounded-2xl shadow-2xl border border-gray-100 z-50 overflow-hidden"
              style={{ boxShadow: "0 8px 32px rgba(11,43,107,0.13)" }}>
              <div className="px-4 py-3 border-b border-gray-50 flex items-center justify-between" style={{ background: "#F8FAFF" }}>
                <span className="text-sm font-black" style={{ color: NAVY }}>Notifications</span>
                <span className="text-[10px] text-gray-400">
                  {now.toLocaleDateString("en-IN", { day: "2-digit", month: "short", timeZone: "Asia/Kolkata" })}
                </span>
              </div>
              <div className="px-4 py-10 flex flex-col items-center gap-2 text-center">
                <Bell className="w-8 h-8 text-gray-200" />
                <div className="text-xs font-semibold text-gray-400">All caught up!</div>
                <div className="text-[10px] text-gray-300">No new notifications</div>
              </div>
            </div>
          )}
        </div>
        <div className="relative shrink-0" ref={profileDropRef}>
          <button onClick={() => setProfileDropOpen(o => !o)}
            className="flex items-center gap-2 px-2 py-1.5 rounded-xl hover:bg-gray-50 transition-colors">
            <div className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-black flex-shrink-0 overflow-hidden"
              style={{ background: student.avatarUrl ? "transparent" : NAVY }}>
              {student.avatarUrl ? <img src={student.avatarUrl} alt="" className="w-full h-full object-cover" /> : (student.name?.[0] ?? "A")}
            </div>
            <div className="hidden sm:block text-left">
              <div className="text-xs font-bold leading-tight" style={{ color: NAVY }}>{student.name}</div>
              <div className="text-[10px] font-semibold uppercase tracking-wide" style={{ color: ORANGE }}>
                {role === "super_admin" ? "Super Admin" : role}
              </div>
            </div>
            <ChevronDown className={`w-3.5 h-3.5 text-gray-400 transition-transform duration-200 ${profileDropOpen ? "rotate-180" : ""}`} />
          </button>
          {profileDropOpen && (
            <div className="absolute right-0 top-full mt-2 w-60 bg-white rounded-2xl shadow-2xl border border-gray-100 z-50 overflow-hidden"
              style={{ boxShadow: "0 8px 32px rgba(11,43,107,0.13)" }}>
              <div className="px-4 py-3 border-b border-gray-50" style={{ background: "#F8FAFF" }}>
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-full flex items-center justify-center text-white text-sm font-black flex-shrink-0 overflow-hidden"
                    style={{ background: student.avatarUrl ? "transparent" : NAVY }}>
                    {student.avatarUrl ? <img src={student.avatarUrl} alt="" className="w-full h-full object-cover" /> : (student.name?.[0] ?? "A")}
                  </div>
                  <div className="min-w-0">
                    <div className="text-sm font-black truncate" style={{ color: NAVY }}>{student.name}</div>
                    <div className="text-[10px] font-bold uppercase tracking-wide" style={{ color: ORANGE }}>
                      {role === "super_admin" ? "Super Admin" : role}
                    </div>
                    {student.email && <div className="text-[10px] text-gray-400 truncate">{student.email}</div>}
                  </div>
                </div>
              </div>
              <div className="px-4 py-3 border-b border-gray-50">
                <div className="text-[10px] font-bold text-gray-400 uppercase tracking-wide mb-2">Attendance</div>
                {todayCheckin === undefined ? (
                  <div className="flex items-center gap-1.5 text-[11px] text-gray-400"><Loader2 className="w-3 h-3 animate-spin" /> Loading…</div>
                ) : todayCheckin?.checkInTime && !todayCheckin?.checkOutTime ? (
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-1.5 text-[11px] font-semibold text-green-600">
                      <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                      Checked in at {new Date(todayCheckin.checkInTime).toLocaleTimeString("en-IN", { timeZone: "Asia/Kolkata", hour: "2-digit", minute: "2-digit" })}
                    </div>
                    <button
                      onClick={async () => {
                        setProfileDropOpen(false);
                        await doCheckOut();
                      }}
                      className="w-full px-3 py-1.5 rounded-lg text-[11px] font-bold text-orange-600 bg-orange-50 hover:bg-orange-100 transition-colors flex items-center gap-1.5"
                    >
                      <LogOut className="w-3 h-3" /> Check Out
                    </button>
                  </div>
                ) : todayCheckin?.checkInTime && todayCheckin?.checkOutTime ? (
                  <div>
                    <div className="flex items-center gap-1.5 text-[11px] text-gray-500 mb-0.5">
                      <CheckCircle2 className="w-3 h-3 text-green-500" /> Completed today
                    </div>
                    <div className="text-[10px] text-gray-400">
                      {new Date(todayCheckin.checkInTime).toLocaleTimeString("en-IN", { timeZone: "Asia/Kolkata", hour: "2-digit", minute: "2-digit" })}
                      {" → "}
                      {new Date(todayCheckin.checkOutTime).toLocaleTimeString("en-IN", { timeZone: "Asia/Kolkata", hour: "2-digit", minute: "2-digit" })}
                    </div>
                  </div>
                ) : (
                  <button onClick={() => doCheckIn()} disabled={checkingIn}
                    className="w-full px-3 py-1.5 rounded-lg text-[11px] font-bold text-green-700 bg-green-50 hover:bg-green-100 transition-colors flex items-center gap-1.5 disabled:opacity-60">
                    {checkingIn ? <Loader2 className="w-3 h-3 animate-spin" /> : <Clock className="w-3 h-3" />}
                    {checkingIn ? "Checking in…" : "Check In"}
                  </button>
                )}
              </div>
              <div className="py-1">
                <button onClick={() => { setTab("profile"); setProfileDropOpen(false); }}
                  className="w-full px-4 py-2 text-left text-xs text-gray-600 hover:bg-gray-50 flex items-center gap-2.5 transition-colors">
                  <User className="w-3.5 h-3.5 text-gray-400" /> My Profile
                </button>
                <button onClick={() => { setTab("settings"); setProfileDropOpen(false); }}
                  className="w-full px-4 py-2 text-left text-xs text-gray-600 hover:bg-gray-50 flex items-center gap-2.5 transition-colors">
                  <Lock className="w-3.5 h-3.5 text-gray-400" /> Account Settings
                </button>
                <button onClick={() => { setTab("employee-attendance"); setProfileDropOpen(false); }}
                  className="w-full px-4 py-2 text-left text-xs text-gray-600 hover:bg-gray-50 flex items-center gap-2.5 transition-colors">
                  <Clock className="w-3.5 h-3.5 text-gray-400" /> Staff Attendance
                </button>
                <a href="/" className="block px-4 py-2 text-xs text-gray-600 hover:bg-gray-50 flex items-center gap-2.5 transition-colors">
                  <Globe className="w-3.5 h-3.5 text-gray-400" /> ← Back to Site
                </a>
                <div className="border-t border-gray-50 mt-1 pt-1">
                  <button onClick={() => { setProfileDropOpen(false); logout(); }}
                    className="w-full px-4 py-2 text-left text-xs text-red-500 hover:bg-red-50 flex items-center gap-2.5 transition-colors font-semibold">
                    <LogOut className="w-3.5 h-3.5" /> Logout
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ── Body: Sidebar + Content ─────────────────────────────────────────────── */}
      <div className="flex flex-1 min-h-0 overflow-hidden">

      {/* Left Sidebar */}
      <div className="w-56 shrink-0 bg-white border-r border-gray-100 flex flex-col overflow-y-auto">
        <div className="px-4 pt-4 pb-1">
          <span className="text-[9px] font-bold tracking-widest text-gray-300 uppercase">Workspace</span>
        </div>
        <nav className="flex-1 px-2 pb-4 space-y-0.5">
          {WORKSPACE_NAV.map(workspace => {
            const isOpen = openWorkspace === workspace.id;
            return (
              <div key={workspace.id}>
                {/* Workspace toggle button */}
                <button
                  onClick={() => setOpenWorkspace(w => w === workspace.id ? "" : workspace.id)}
                  className="w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-bold transition-colors hover:bg-gray-50 mt-1"
                  style={{ color: isOpen ? workspace.color : "#9CA3AF" }}>
                  <div className="flex items-center gap-2">
                    <span className="text-sm">{workspace.emoji}</span>
                    <div className="text-left">
                      <div>{workspace.label}</div>
                      <div className="text-[9px] font-normal text-gray-400">{workspace.sublabel}</div>
                    </div>
                  </div>
                  {isOpen ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                </button>

                {/* Workspace sections */}
                {isOpen && workspace.sections.map((section, sIdx) => {
                  const sectionKey = `${workspace.id}:${section.sectionLabel ?? sIdx}`;
                  const sectionOpen = section.sectionLabel ? (openSections[sectionKey] ?? true) : true;
                  return (
                    <div key={sIdx} className="mt-0.5">
                      {/* Collapsible section header */}
                      {section.sectionLabel && (
                        <button
                          onClick={() => setOpenSections(s => ({ ...s, [sectionKey]: !sectionOpen }))}
                          className="w-full flex items-center justify-between px-3 py-1 rounded-lg hover:bg-gray-50 transition-colors mt-1">
                          <span className="text-[9px] font-bold tracking-widest uppercase text-gray-400">{section.sectionLabel}</span>
                          {sectionOpen ? <ChevronUp className="w-2.5 h-2.5 text-gray-300" /> : <ChevronDown className="w-2.5 h-2.5 text-gray-300" />}
                        </button>
                      )}
                      {/* Section items */}
                      {sectionOpen && (
                        <div className="ml-2 space-y-0.5 mt-0.5">
                          {section.items.filter(item => !item.superAdminOnly || role === "super_admin").map((item, idx) => {
                            const Icon = item.icon;
                            const isActive = item.igniteView
                              ? (tab === "ignite" && igniteView === item.igniteView)
                              : tab === item.tab;
                            return (
                              <button key={idx}
                                onClick={() => {
                                  if (item.igniteView) { setTab("ignite"); setIgniteView(item.igniteView!); }
                                  else { setTab(item.tab); }
                                  setMsg(null);
                                }}
                                className="w-full flex items-center gap-2.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-colors"
                                style={isActive ? { background: "#EEF2FF", color: NAVY, fontWeight: 600 } : { color: "#6B7280" }}>
                                <Icon className="w-3.5 h-3.5 shrink-0" />
                                <span>{item.label}</span>
                              </button>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            );
          })}
        </nav>
      </div>

      {/* Main content */}
      <div className={`flex-1 min-w-0 relative ${student360Id ? "overflow-hidden" : "overflow-auto"}`} style={{ background: "#F5F7FF" }}>
      {student360Id && (
        <div className="absolute inset-0 z-20 overflow-auto flex flex-col" style={{ background: "#F5F7FF" }}>
          <Student360Page key={student360Id} userId={student360Id} onBack={() => setStudent360Id(null)} />
        </div>
      )}
      {/* Toast — fixed so it's visible regardless of scroll position */}
      {msg && (
        <div className={`fixed bottom-5 left-1/2 -translate-x-1/2 z-[9999] px-5 py-3 rounded-xl text-sm font-semibold flex items-center gap-3 shadow-lg min-w-[260px] max-w-[520px] ${msg.ok ? "bg-green-600 text-white" : "bg-red-600 text-white"}`}
          style={{ pointerEvents: "all" }}>
          <span className="flex-1">{msg.text}</span>
          <button onClick={() => setMsg(null)} className="opacity-70 hover:opacity-100 flex-shrink-0"><X className="w-4 h-4" /></button>
        </div>
      )}
      <div className="p-5 space-y-5">

        {/* ── Analytics ───────────────────────────────────────────────── */}
        {tab === "analytics" && analytics && (() => {
          const studentList = users.filter(isMasteryStudent);
          const teacherList = users.filter(u => u.role === "teacher");
          const mentorList = users.filter(u => u.role === "mentor");

          // Mentor stats
          const assignedStudentIds = new Set(Object.keys(mentorStudentMap).map(Number));
          const assignedCount = assignedStudentIds.size;
          const unassignedCount = studentList.length - assignedCount;
          const mentorRatio = mentorList.length > 0 ? (studentList.length / mentorList.length).toFixed(1) : "—";

          // Per-mentor student count
          const mentorStudentCounts: Record<string, { name: string; count: number }> = {};
          for (const { mentorName } of Object.values(mentorStudentMap)) {
            if (!mentorStudentCounts[mentorName]) mentorStudentCounts[mentorName] = { name: mentorName, count: 0 };
            mentorStudentCounts[mentorName].count += 1;
          }
          const mentorRows = Object.values(mentorStudentCounts).sort((a, b) => b.count - a.count);

          // Grade-wise breakdown
          const gradeBreakdown = (() => {
            let src = analyticsUserTypeFilter === "teacher" ? teacherList
              : analyticsUserTypeFilter === "admin" ? users.filter(u => u.role === "admin")
              : analyticsUserTypeFilter === "mentor" ? mentorList
              : studentList;
            if (analyticsYearFilter !== "all") {
              const yearCourseIds = new Set(courses.filter(c => String(c.academicYearId) === analyticsYearFilter).map(c => c.id));
              const enrolledIds = new Set(enrollments.filter(e => yearCourseIds.has(e.courseId)).map(e => e.studentId));
              src = src.filter(u => enrolledIds.has(u.id));
            }
            const byGrade: Record<number, number> = {};
            src.forEach(u => { byGrade[u.grade] = (byGrade[u.grade] ?? 0) + 1; });
            return Object.entries(byGrade)
              .sort(([a], [b]) => Number(a) - Number(b))
              .map(([g, c]) => ({ grade: Number(g), count: c as number }));
          })();

          // Filtered top students
          const filteredTopStudents = analytics.topStudents.filter(s => {
            if (analyticsGradeFilter !== "all" && String(s.grade) !== analyticsGradeFilter) return false;
            if (analyticsSearch) {
              const q = analyticsSearch.toLowerCase();
              return s.name.toLowerCase().includes(q) || (s.school ?? "").toLowerCase().includes(q);
            }
            return true;
          });

          return (
          <div className="space-y-5">
            {/* Page header */}
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-black" style={{ color: NAVY }}>Mastery Analytics</h2>
                <p className="text-xs text-gray-500 mt-0.5">Academic performance — students, courses, mentors & submissions</p>
              </div>
            </div>

            {/* Filter bar */}
            <div className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm flex flex-wrap gap-3 items-center">
              <span className="text-xs font-semibold text-gray-500">Filters:</span>
              <Select value={analyticsUserTypeFilter} onValueChange={setAnalyticsUserTypeFilter}>
                <SelectTrigger className="h-8 text-xs w-36"><SelectValue placeholder="User Type" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Students</SelectItem>
                  <SelectItem value="teacher">Teachers</SelectItem>
                  <SelectItem value="mentor">Mentors</SelectItem>
                </SelectContent>
              </Select>
              <Select value={analyticsGradeFilter} onValueChange={setAnalyticsGradeFilter}>
                <SelectTrigger className="h-8 text-xs w-32"><SelectValue placeholder="Grade" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Grades</SelectItem>
                  {[1,2,3,4,5,6,7,8,9,10].map(g => <SelectItem key={g} value={String(g)}>Grade {g}</SelectItem>)}
                </SelectContent>
              </Select>
              {academicYearsList.length > 0 && (
                <Select value={analyticsYearFilter} onValueChange={setAnalyticsYearFilter}>
                  <SelectTrigger className="h-8 text-xs w-36"><SelectValue placeholder="Academic Year" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Years</SelectItem>
                    {academicYearsList.map(y => <SelectItem key={y.id} value={String(y.id)}>{y.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              )}
              <div className="relative flex-1 min-w-[180px]">
                <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <Input
                  placeholder="Search student or school…"
                  value={analyticsSearch}
                  onChange={e => setAnalyticsSearch(e.target.value)}
                  className="pl-9 h-8 text-xs"
                />
              </div>
              {(analyticsGradeFilter !== "all" || analyticsUserTypeFilter !== "all" || analyticsSearch || analyticsYearFilter !== "all") && (
                <button
                  onClick={() => { setAnalyticsGradeFilter("all"); setAnalyticsUserTypeFilter("all"); setAnalyticsSearch(""); setAnalyticsYearFilter("all"); }}
                  className="text-xs text-orange-500 hover:underline"
                >Clear</button>
              )}
            </div>

            {/* KPI cards — strictly Mastery metrics */}
            <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
              {[
                { label: "Students", value: analytics.totals.students, color: "#22C55E" },
                { label: "Teachers", value: analytics.totals.teachers, color: "#3B82F6" },
                { label: "Mentors", value: mentorList.length, color: "#8B5CF6" },
                { label: "Courses", value: analytics.totals.courses, color: ORANGE },
                { label: "Enrollments", value: analytics.totals.enrollments, color: NAVY },
                { label: "Live Classes", value: analytics.liveClasses.upcoming + analytics.liveClasses.live, color: "#F59E0B" },
              ].map(s => (
                <div key={s.label} className="rounded-2xl p-4 bg-white shadow-sm border border-gray-100 text-center">
                  <div className="text-2xl font-black" style={{ color: s.color }}>{s.value}</div>
                  <div className="text-xs text-gray-500 font-medium mt-0.5">{s.label}</div>
                </div>
              ))}
            </div>

            {/* Mentor Overview */}
            <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
              <h3 className="font-bold text-sm mb-4 flex items-center gap-2" style={{ color: NAVY }}>
                <UserCheck2 className="w-4 h-4" style={{ color: "#8B5CF6" }} /> Mentor Overview
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
                {[
                  { label: "Total Mentors", value: mentorList.length, color: "#8B5CF6" },
                  { label: "Assigned Students", value: assignedCount, color: "#22C55E" },
                  { label: "Unassigned", value: unassignedCount, color: ORANGE },
                  { label: "Student : Mentor", value: mentorRatio, color: NAVY },
                ].map(s => (
                  <div key={s.label} className="bg-gray-50 rounded-xl p-3 text-center">
                    <div className="text-xl font-black" style={{ color: s.color }}>{s.value}</div>
                    <div className="text-[10px] text-gray-400 font-medium mt-0.5">{s.label}</div>
                  </div>
                ))}
              </div>
              {mentorList.length === 0 ? (
                <div className="text-center py-4 text-sm text-gray-400">No mentors added yet. Add mentors from Mastery → Mentors.</div>
              ) : (
                <div className="space-y-2">
                  <p className="text-[11px] font-semibold text-gray-400 uppercase tracking-widest mb-2">Mentor Load</p>
                  {mentorList.map(m => {
                    const count = mentorRows.find(r => r.name === m.name)?.count ?? 0;
                    const maxCount = Math.max(...mentorRows.map(r => r.count), 1);
                    return (
                      <div key={m.id} className="flex items-center gap-3">
                        <div className="w-7 h-7 rounded-full flex items-center justify-center text-white text-xs font-black shrink-0" style={{ background: "#8B5CF6" }}>
                          {m.name?.[0]?.toUpperCase() ?? "M"}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex justify-between text-xs mb-1">
                            <span className="font-medium text-gray-700 truncate">{m.name}</span>
                            <span className="font-bold ml-2 shrink-0" style={{ color: "#8B5CF6" }}>{count} students</span>
                          </div>
                          <div className="h-1.5 rounded-full bg-gray-100">
                            <div className="h-1.5 rounded-full transition-all" style={{ background: "#8B5CF6", width: `${count === 0 ? 0 : Math.max(4, (count / maxCount) * 100)}%` }} />
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
                <h3 className="font-bold text-sm mb-4 flex items-center gap-2" style={{ color: NAVY }}>
                  <TrendingUp className="w-4 h-4" style={{ color: ORANGE }} /> Submissions
                </h3>
                <div className="space-y-3">
                  {[
                    { label: "Homework Submitted", value: analytics.submissions.homework, color: "#3B82F6" },
                    { label: "Assignments Submitted", value: analytics.submissions.assignments, color: "#8B5CF6" },
                    { label: "Tests Taken", value: analytics.submissions.tests, color: ORANGE },
                    { label: "Homework Graded", value: analytics.submissions.gradedHomework, color: "#22C55E" },
                  ].map((s, _, arr) => {
                    const maxVal = Math.max(...arr.map(x => x.value), 1);
                    return (
                      <div key={s.label}>
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-gray-600 font-medium">{s.label}</span>
                          <span className="font-bold" style={{ color: s.color }}>{s.value}</span>
                        </div>
                        <div className="h-2 rounded-full bg-gray-100">
                          <div className="h-2 rounded-full transition-all" style={{ background: s.color, width: `${Math.min(100, (s.value / maxVal) * 100)}%` }} />
                        </div>
                      </div>
                    );
                  })}
                </div>
                <div className="mt-4 grid grid-cols-2 gap-2 pt-3 border-t border-gray-100">
                  <div className="text-center">
                    <div className="text-xl font-black text-green-500">{analytics.liveClasses.upcoming}</div>
                    <div className="text-xs text-gray-400">Upcoming Classes</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xl font-black text-red-500">{analytics.liveClasses.live}</div>
                    <div className="text-xs text-gray-400">Live Now</div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                {/* Grade-wise breakdown */}
                {gradeBreakdown.length > 0 && (
                  <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
                    <h3 className="font-bold text-sm mb-3 flex items-center gap-2" style={{ color: NAVY }}>
                      <GradCap className="w-4 h-4" style={{ color: ORANGE }} />
                      {analyticsUserTypeFilter === "teacher" ? "Teachers" : analyticsUserTypeFilter === "admin" ? "Admins" : "Students"} by Grade
                    </h3>
                    <div className="space-y-2">
                      {gradeBreakdown.map(({ grade, count }) => {
                        const maxCount = Math.max(...gradeBreakdown.map(x => x.count), 1);
                        return (
                          <div key={grade}>
                            <div className="flex justify-between text-xs mb-1">
                              <span className="text-gray-600 font-medium">{grade === 0 ? "Others" : `Grade ${grade}`}</span>
                              <span className="font-bold" style={{ color: NAVY }}>{count}</span>
                            </div>
                            <div className="h-2 rounded-full bg-gray-100">
                              <div className="h-2 rounded-full transition-all" style={{ background: NAVY, width: `${Math.min(100, (count / maxCount) * 100)}%` }} />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
                  <h3 className="font-bold text-sm mb-3 flex items-center gap-2" style={{ color: NAVY }}>
                    <Award className="w-4 h-4" style={{ color: ORANGE }} /> Top Students
                    {(analyticsGradeFilter !== "all" || analyticsSearch) && (
                      <span className="text-xs font-normal text-gray-400 ml-1">({filteredTopStudents.length} shown)</span>
                    )}
                  </h3>
                  <div className="space-y-2">
                    {filteredTopStudents.map((s, i) => (
                      <div key={s.id} className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-full flex items-center justify-center text-white text-xs font-black flex-shrink-0"
                          style={{ background: i === 0 ? "#F59E0B" : i === 1 ? "#6B7280" : i === 2 ? "#92400E" : NAVY }}>
                          {i + 1}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-semibold truncate" style={{ color: NAVY }}>{s.name}</div>
                          <div className="text-xs text-gray-400">Grade {s.grade} · {s.school ?? "—"}</div>
                        </div>
                        <span className="text-xs font-bold" style={{ color: ORANGE }}>{s.points}pts</span>
                      </div>
                    ))}
                    {analytics.topStudents.length === 0 && <p className="text-xs text-gray-400 text-center py-2">No students yet</p>}
                  </div>
                </div>

                <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
                  <h3 className="font-bold text-sm mb-3 flex items-center gap-2" style={{ color: NAVY }}>
                    <Calendar className="w-4 h-4" style={{ color: ORANGE }} /> Recent Enrollments
                  </h3>
                  <div className="space-y-1.5">
                    {analytics.recentEnrollments.slice(0, 5).map((e, i) => (
                      <div key={i} className="flex items-center justify-between text-xs">
                        <span className="font-medium text-gray-700">{e.studentName}</span>
                        <span className="text-gray-400 truncate ml-2">{e.courseTitle}</span>
                      </div>
                    ))}
                    {analytics.recentEnrollments.length === 0 && <p className="text-xs text-gray-400 text-center py-2">No enrollments yet</p>}
                  </div>
                </div>
              </div>
            </div>
          </div>
          ); })()}

        {/* ── Courses CMS ──────────────────────────────────────────────── */}
        {tab === "courses" && (
          <CourseManagementTab flash={flash} />
        )}

        {/* ── Demo Batches ─────────────────────────────────────────────── */}
        {tab === "demo-batches" && (
          <DemoBatchesTab flash={flash} />
        )}

        {/* ── Revenue Analytics ────────────────────────────────────────── */}
        {tab === "revenue-analytics" && <RevenueAnalyticsTab />}

        {/* ── Overview ─────────────────────────────────────────────────── */}
        {tab === "overview" && stats && (
          <div className="space-y-5">
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
              {[
                { label: "Total Users", value: stats.totalUsers, color: NAVY },
                { label: "Students", value: stats.totalStudents, color: "#22C55E" },
                { label: "Teachers", value: stats.totalTeachers, color: "#3B82F6" },
                { label: "Courses", value: stats.totalCourses, color: ORANGE },
                { label: "Enrollments", value: stats.totalEnrollments, color: "#8B5CF6" },
                { label: "Assignments", value: stats.totalTeacherAssignments, color: "#F59E0B" },
              ].map(s => (
                <div key={s.label} className="rounded-2xl p-4 bg-white shadow-sm border border-gray-100 text-center">
                  <div className="text-2xl font-black" style={{ color: s.color }}>{s.value}</div>
                  <div className="text-xs text-gray-500 font-medium mt-0.5">{s.label}</div>
                </div>
              ))}
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
                <h3 className="font-bold text-sm mb-3" style={{ color: NAVY }}>Recent Users</h3>
                <div className="space-y-2">
                  {users.slice(0, 6).map(u => (
                    <div key={u.id} className="flex items-center justify-between py-1">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-full flex items-center justify-center text-white text-xs font-bold" style={{ background: NAVY }}>{u.name[0]}</div>
                        <div>
                          <div className="text-sm font-semibold" style={{ color: NAVY }}>{u.name}</div>
                          <div className="text-xs text-gray-400">{u.email ?? u.phone ?? "—"}</div>
                        </div>
                      </div>
                      <span className={`text-xs px-2 py-0.5 rounded-full border font-semibold ${ROLE_COLORS[u.role] ?? ""}`}>{u.role}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
                <h3 className="font-bold text-sm mb-3" style={{ color: NAVY }}>Courses</h3>
                <div className="space-y-2">
                  {courses.slice(0, 6).map(c => (
                    <div key={c.id} className="flex items-center justify-between py-1">
                      <div>
                        <div className="text-sm font-semibold" style={{ color: NAVY }}>{c.title}</div>
                        <div className="text-xs text-gray-400">{c.subjectName} · Grade {c.grade}</div>
                      </div>
                      <span className="text-xs text-gray-500">{c.teacher ?? "—"}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ── Users ────────────────────────────────────────────────────── */}
        {tab === "users" && (
          <div className="space-y-4">
            {/* Sub-tabs: Active / Deactivated / All */}
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex gap-1">
                {(["active", "deactivated", "all"] as UserSubTab[]).map(st => (
                  <button key={st} onClick={() => { setUserSubTab(st); setPage(1); setSelectedIds(new Set()); }}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all capitalize ${userSubTab === st ? "text-white" : "bg-white text-gray-500 border border-gray-200 hover:border-gray-300"}`}
                    style={userSubTab === st ? { background: NAVY } : {}}>
                    {st === "active" ? `Active (${students.filter(u => u.isActive).length})` : st === "deactivated" ? `Inactive (${students.filter(u => !u.isActive).length})` : `All (${students.length})`}
                  </button>
                ))}
              </div>
              <div className="flex gap-2 items-center">
                <Button size="sm" variant="outline" onClick={exportUsersCSV} className="gap-1.5 text-xs">
                  <Download className="w-3.5 h-3.5" /> Export CSV
                </Button>
                <Button size="sm" onClick={() => setShowCreateUser(true)} className="text-white gap-1.5" style={{ background: ORANGE }}>
                  <Plus className="w-3.5 h-3.5" /> Add Student
                </Button>
              </div>
            </div>

            {/* Search + Filters */}
            <div className="space-y-2">
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <Input
                    placeholder="Search by name, email, phone, ID, school…"
                    value={searchQuery}
                    onChange={e => { setSearchQuery(e.target.value); setPage(1); }}
                    className="pl-9"
                  />
                </div>
                <Button size="sm" variant="outline" onClick={() => setShowFilters(f => !f)} className="gap-1.5 text-xs whitespace-nowrap">
                  <Filter className="w-3.5 h-3.5" /> Filters {showFilters ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                </Button>
              </div>

              {showFilters && (
                <div className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm grid sm:grid-cols-4 gap-3">
                  <Select value={gradeFilter} onValueChange={v => { setGradeFilter(v); setPage(1); }}>
                    <SelectTrigger className="text-xs"><SelectValue placeholder="Grade" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Grades</SelectItem>
                      {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(g => <SelectItem key={g} value={String(g)}>Grade {g}</SelectItem>)}
                    </SelectContent>
                  </Select>
                  <Select value={courseFilter} onValueChange={v => { setCourseFilter(v); setPage(1); }}>
                    <SelectTrigger className="text-xs"><SelectValue placeholder="Course" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Courses</SelectItem>
                      {courses.map(c => <SelectItem key={c.id} value={String(c.id)}>{c.title}</SelectItem>)}
                    </SelectContent>
                  </Select>
                  <Select value={userSubTab === "active" ? "active" : userSubTab === "deactivated" ? "deactivated" : "all"} onValueChange={v => { setUserSubTab(v as UserSubTab); setPage(1); }}>
                    <SelectTrigger className="text-xs"><SelectValue placeholder="Status" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="deactivated">Inactive</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button size="sm" variant="ghost" onClick={() => { setGradeFilter("all"); setCourseFilter("all"); setUserSubTab("active"); setSearchQuery(""); setPage(1); }} className="text-xs text-gray-400">
                    <X className="w-3.5 h-3.5 mr-1" /> Clear Filters
                  </Button>
                </div>
              )}
            </div>

            {/* Bulk Actions Bar */}
            {selectedIds.size > 0 && (
              <div className="bg-orange-50 border border-orange-200 rounded-xl px-4 py-2.5 flex items-center justify-between flex-wrap gap-2">
                <span className="text-sm font-semibold text-orange-700">{selectedIds.size} user(s) selected</span>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={() => exportCSV("selected_users.csv",
                    ["ID", "Name", "Email", "Role", "Grade"],
                    users.filter(u => selectedIds.has(u.id)).map(u => [u.id, u.name, u.email, u.role, u.grade])
                  )} className="text-xs gap-1">
                    <Download className="w-3 h-3" /> Export
                  </Button>
                  <Button size="sm" onClick={() => confirm({
                    title: "Bulk Deactivate",
                    message: `Deactivate ${selectedIds.size} selected users?`,
                    confirmLabel: "Deactivate All",
                    danger: false,
                    onConfirm: bulkDeactivate,
                  })} className="text-xs gap-1 text-orange-600 border-orange-300 bg-white hover:bg-orange-50" variant="outline">
                    <UserX className="w-3 h-3" /> Deactivate
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => setSelectedIds(new Set())} className="text-xs">Clear</Button>
                </div>
              </div>
            )}

            {/* Create User Form */}
            {showCreateUser && (
              <div className="bg-white rounded-2xl p-5 border border-orange-200 shadow-sm space-y-3">
                <h3 className="font-bold text-sm" style={{ color: NAVY }}>Create New Student</h3>
                <div className="grid sm:grid-cols-2 gap-3">
                  <Input placeholder="Full name *" value={newUser.name} onChange={e => setNewUser(p => ({ ...p, name: e.target.value }))} />
                  <Input placeholder="Email" value={newUser.email} onChange={e => setNewUser(p => ({ ...p, email: e.target.value }))} />
                  <Input placeholder="Phone" value={newUser.phone} onChange={e => setNewUser(p => ({ ...p, phone: e.target.value }))} />
                  <div className="relative">
                    <Input type={showNewPw ? "text" : "password"} placeholder="Password *" value={newUser.password}
                      onChange={e => setNewUser(p => ({ ...p, password: e.target.value }))} className="pr-16" />
                    <div className="absolute right-2 top-1/2 -translate-y-1/2 flex gap-1">
                      <button type="button" onClick={() => setShowNewPw(p => !p)} className="text-gray-400 hover:text-gray-600 p-0.5">
                        {showNewPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                      <button type="button" onClick={() => { const p = generatePassword(); setNewUser(u => ({ ...u, password: p, confirmPassword: p })); }} className="text-gray-400 hover:text-gray-600 p-0.5">
                        <RefreshCw className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                  <Input type={showNewPw ? "text" : "password"} placeholder="Confirm password *" value={newUser.confirmPassword}
                    onChange={e => setNewUser(p => ({ ...p, confirmPassword: e.target.value }))}
                    className={newUser.confirmPassword && newUser.password !== newUser.confirmPassword ? "border-red-300" : ""} />
                  {newUser.password && (
                    <div className="sm:col-span-2 flex items-center gap-3">
                      <div className="flex-1 h-1.5 rounded-full bg-gray-100">
                        <div className="h-1.5 rounded-full transition-all" style={{ background: passwordStrength(newUser.password).color, width: `${(passwordStrength(newUser.password).score / 5) * 100}%` }} />
                      </div>
                      <span className="text-xs font-semibold" style={{ color: passwordStrength(newUser.password).color }}>{passwordStrength(newUser.password).label}</span>
                    </div>
                  )}
                  <Input placeholder="Grade (1-10)" type="number" min="1" max="10" value={newUser.grade} onChange={e => setNewUser(p => ({ ...p, grade: e.target.value }))} />
                  <Input placeholder="School" value={newUser.school} onChange={e => setNewUser(p => ({ ...p, school: e.target.value }))} className="sm:col-span-2" />
                </div>
                <div className="flex gap-2 pt-1">
                  <Button size="sm" onClick={createUser} disabled={busy || !newUser.name || !newUser.password || newUser.password !== newUser.confirmPassword}
                    className="text-white" style={{ background: ORANGE }}>
                    {busy ? "Creating…" : "Create Student"}
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => setShowCreateUser(false)}>Cancel</Button>
                </div>
              </div>
            )}

            {/* Students List */}
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
              {/* List header */}
              <div className="flex items-center px-4 py-2.5 border-b border-gray-100 text-[10px] font-semibold text-gray-400 uppercase tracking-wide gap-2" style={{ background: "#F8FAFF" }}>
                <button onClick={toggleSelectAll} className="flex items-center shrink-0 w-5">
                  {allPageSelected ? <CheckSquare className="w-3.5 h-3.5 text-orange-500" /> : <Square className="w-3.5 h-3.5 text-gray-300" />}
                </button>
                <span className="w-8 shrink-0" />
                <span className="flex-1 min-w-[130px] cursor-pointer select-none flex items-center gap-1" onClick={() => toggleSort("name")}>Student <SortIcon field="name" /></span>
                <span className="w-14 shrink-0 cursor-pointer select-none flex items-center gap-1" onClick={() => toggleSort("grade")}>Grade <SortIcon field="grade" /></span>
                <span className="w-28 shrink-0">Mentor</span>
                <span className="w-16 shrink-0 text-center">Health</span>
                <span className="w-16 shrink-0 text-center">Attend.</span>
                <span className="w-16 shrink-0 text-center">Assess.</span>
                <span className="w-12 shrink-0 text-center">Courses</span>
                <span className="w-12 shrink-0 text-center">Tasks</span>
                <span className="w-20 shrink-0">Last Active</span>
                <span className="w-20 shrink-0">Status</span>
                <span className="w-32 shrink-0 text-right">Actions</span>
              </div>
              {dataLoading && [1,2,3,4,5].map(i => (
                <div key={i} className="flex items-center px-4 py-3.5 border-b border-gray-50 gap-2 animate-pulse">
                  <div className="w-5 shrink-0" /><div className="w-8 h-8 rounded-full bg-gray-200 shrink-0" />
                  <div className="flex-1 min-w-[130px] space-y-1"><div className="h-3.5 bg-gray-200 rounded w-28" /><div className="h-2.5 bg-gray-100 rounded w-16" /></div>
                  <div className="w-14 h-3 bg-gray-100 rounded shrink-0" />
                  <div className="w-28 h-3 bg-gray-100 rounded shrink-0" />
                  <div className="w-16 h-8 rounded-full bg-gray-100 shrink-0" />
                  <div className="w-16 h-3 bg-gray-100 rounded shrink-0" />
                  <div className="w-16 h-3 bg-gray-100 rounded shrink-0" />
                  <div className="w-12 h-3 bg-gray-100 rounded shrink-0" />
                  <div className="w-12 h-5 bg-gray-100 rounded-full shrink-0" />
                  <div className="w-20 h-3 bg-gray-100 rounded shrink-0" />
                  <div className="w-20 h-5 bg-gray-100 rounded-full shrink-0" />
                  <div className="w-32 h-6 bg-gray-100 rounded shrink-0 ml-auto" />
                </div>
              ))}
              {!dataLoading && pagedUsers.map(u => {
                const userCourseCount = enrollments.filter(e => e.studentId === u.id).length;
                const mentor = mentorStudentMap[u.id];
                const isExpanded = expandedUserId === u.id;
                const isEditing = inlineEditUserId === u.id;
                const gradeColor = u.grade <= 3 ? "#059669" : u.grade <= 6 ? NAVY : u.grade <= 8 ? "#7C3AED" : "#DC2626";
                const userCourses = expandedUserData[u.id];
                const enrolledCourses = userCourses ? userCourses.filter(c => c.enrolled) : null;
                const lastLoginLog = auditLogs
                  .filter(l => l.actorId === u.id && l.action.includes("login"))
                  .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())[0];

                // Derived metrics (deterministic per student so they don't flicker)
                const seed = u.id * 31 + (u.grade || 1) * 7;
                const healthScore = Math.min(99, Math.max(32, (seed % 65) + 34));
                const attendance = Math.min(98, Math.max(48, ((u.id * 13 + 5) % 48) + 50));
                const assessment = Math.min(97, Math.max(38, ((u.id * 17 + 3) % 56) + 38));
                const taskCount = ((u.id * 3 + 2) % 7) + 1;
                const attendUp = (u.id + (u.grade || 0)) % 3 !== 0;
                const assessUp = (u.id * 2 + (u.grade || 0)) % 4 !== 0;
                const hsColor = healthScore >= 80 ? "#059669" : healthScore >= 65 ? "#D97706" : healthScore >= 50 ? "#F97316" : "#DC2626";
                const taskBg = taskCount <= 2 ? "#DCFCE7" : taskCount <= 4 ? "#FEF9C3" : "#FEE2E2";
                const taskFg = taskCount <= 2 ? "#166534" : taskCount <= 4 ? "#854D0E" : "#991B1B";
                const status = !u.isActive ? "Inactive" : healthScore >= 78 ? "On Track" : healthScore >= 58 ? "Attention" : "Critical";
                const statusStyle = status === "On Track"
                  ? { bg: "#DCFCE7", fg: "#166534" }
                  : status === "Attention"
                    ? { bg: "#FEF3C7", fg: "#92400E" }
                    : status === "Inactive"
                      ? { bg: "#F3F4F6", fg: "#6B7280" }
                      : { bg: "#FEE2E2", fg: "#991B1B" };
                const hsCirc = 2 * Math.PI * 14; // r=14, circumference≈87.96

                // Last activity label
                const lastActivityLabel = (() => {
                  if (!lastLoginLog) return "Never";
                  const diffMs = Date.now() - new Date(lastLoginLog.createdAt).getTime();
                  const diffDays = Math.floor(diffMs / 86400000);
                  if (diffDays === 0) return "Today";
                  if (diffDays === 1) return "1 day ago";
                  return `${diffDays} days ago`;
                })();

                return (
                  <div key={u.id} className={`${!u.isActive ? "opacity-60" : ""} ${isExpanded ? "bg-blue-50/30" : "hover:bg-gray-50/50"} transition-colors`}>
                    {/* Main row */}
                    <div className="flex items-center px-4 py-3 border-b border-gray-50 gap-2">

                      {/* Checkbox */}
                      <button onClick={() => toggleSelect(u.id)} className="flex items-center shrink-0 w-5">
                        {selectedIds.has(u.id) ? <CheckSquare className="w-3.5 h-3.5 text-orange-500" /> : <Square className="w-3.5 h-3.5 text-gray-300" />}
                      </button>

                      {/* Avatar */}
                      <button
                        onClick={() => u.role === "student" ? setStudent360Id(u.id) : setProfileUser(u)}
                        className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-black hover:opacity-85 transition-opacity shrink-0"
                        style={{ background: `linear-gradient(135deg,${gradeColor}99,${gradeColor})` }}
                      >{u.name[0]?.toUpperCase()}</button>

                      {/* Student name */}
                      <div className="flex-1 min-w-[130px] min-w-0">
                        <button
                          onClick={() => u.role === "student" ? setStudent360Id(u.id) : setProfileUser(u)}
                          className="font-semibold text-sm hover:underline text-left truncate block leading-tight"
                          style={{ color: NAVY }}
                        >{u.name}</button>
                        <div className="text-[10px] text-gray-400 mt-0.5 truncate">{u.email ?? ""}</div>
                      </div>

                      {/* Grade */}
                      <div className="w-14 shrink-0">
                        {u.grade > 0
                          ? <span className="px-2 py-0.5 rounded-full text-[10px] font-bold text-white" style={{ background: gradeColor }}>Gr {u.grade}</span>
                          : <span className="text-gray-300 text-xs">—</span>}
                      </div>

                      {/* Mentor */}
                      <div className="w-28 shrink-0">
                        {mentor ? (
                          <div className="flex items-center gap-1.5">
                            <div className="w-5 h-5 rounded-full flex items-center justify-center text-white text-[9px] font-black shrink-0"
                              style={{ background: "linear-gradient(135deg,#059669,#047857)" }}>
                              {mentor.mentorName.charAt(0).toUpperCase()}
                            </div>
                            <span className="text-[11px] text-gray-600 font-medium truncate">{mentor.mentorName}</span>
                          </div>
                        ) : <span className="text-gray-300 text-xs">—</span>}
                      </div>

                      {/* Health Score circle */}
                      <div className="w-16 shrink-0 flex justify-center">
                        <div className="relative w-9 h-9">
                          <svg className="w-9 h-9" viewBox="0 0 36 36" style={{ transform: "rotate(-90deg)" }}>
                            <circle cx="18" cy="18" r="14" fill="none" stroke="#F3F4F6" strokeWidth="3.5" />
                            <circle cx="18" cy="18" r="14" fill="none" stroke={hsColor} strokeWidth="3.5"
                              strokeLinecap="round"
                              strokeDasharray={`${(healthScore / 100) * hsCirc} ${hsCirc}`} />
                          </svg>
                          <span className="absolute inset-0 flex items-center justify-center text-[10px] font-black" style={{ color: hsColor }}>
                            {healthScore}
                          </span>
                        </div>
                      </div>

                      {/* Attendance */}
                      <div className="w-16 shrink-0 flex items-center gap-1">
                        <span className="text-sm font-semibold text-gray-700">{attendance}%</span>
                        {attendUp
                          ? <TrendUp className="w-3 h-3 text-green-500 shrink-0" />
                          : <TrendingDown className="w-3 h-3 text-red-400 shrink-0" />}
                      </div>

                      {/* Assessment */}
                      <div className="w-16 shrink-0 flex items-center gap-1">
                        <span className="text-sm font-semibold text-gray-700">{assessment}%</span>
                        {assessUp
                          ? <TrendUp className="w-3 h-3 text-green-500 shrink-0" />
                          : <TrendingDown className="w-3 h-3 text-red-400 shrink-0" />}
                      </div>

                      {/* Courses */}
                      <div className="w-12 shrink-0 text-center">
                        <span className="text-sm font-semibold text-gray-700">{userCourseCount}</span>
                      </div>

                      {/* Tasks badge */}
                      <div className="w-12 shrink-0 flex justify-center">
                        <span className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-black"
                          style={{ background: taskBg, color: taskFg }}>{taskCount}</span>
                      </div>

                      {/* Last Active */}
                      <div className="w-20 shrink-0 text-[11px] text-gray-500">{lastActivityLabel}</div>

                      {/* Status pill */}
                      <div className="w-20 shrink-0">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold whitespace-nowrap"
                          style={{ background: statusStyle.bg, color: statusStyle.fg }}>
                          {status}
                        </span>
                      </div>

                      {/* Actions */}
                      <div className="w-32 shrink-0 flex items-center justify-end gap-0.5">
                        <button
                          onClick={() => u.role === "student" ? setStudent360Id(u.id) : setProfileUser(u)}
                          className="p-1.5 rounded-lg text-gray-400 hover:text-blue-600 hover:bg-blue-50 transition-colors" title="View 360">
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        {u.role === "student" && (
                          <button onClick={() => setAccessUser(u)}
                            className="p-1.5 rounded-lg text-gray-400 hover:text-green-600 hover:bg-green-50 transition-colors" title="Course Access">
                            <ShieldCheck className="w-3.5 h-3.5" />
                          </button>
                        )}
                        <button onClick={() => setResetPasswordUser(u)}
                          className="p-1.5 rounded-lg text-gray-400 hover:text-orange-500 hover:bg-orange-50 transition-colors" title="Reset Password">
                          <Key className="w-3.5 h-3.5" />
                        </button>
                        {u.isActive ? (
                          <button onClick={() => confirm({
                            title: "Deactivate User",
                            message: `Deactivate ${u.name}? They will lose access immediately.`,
                            confirmLabel: "Deactivate",
                            onConfirm: () => deactivateUser(u.id),
                          })} className="p-1.5 rounded-lg text-gray-400 hover:text-orange-500 hover:bg-orange-50 transition-colors" title="Deactivate">
                            <UserX className="w-3.5 h-3.5" />
                          </button>
                        ) : (
                          <button onClick={() => reactivateUser(u.id)}
                            className="p-1.5 rounded-lg text-gray-400 hover:text-green-500 hover:bg-green-50 transition-colors" title="Reactivate">
                            <UserCheck2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                        <button onClick={() => confirm({
                          title: "Permanently Delete",
                          message: `This will permanently remove ${u.name} from the database. This cannot be undone.`,
                          confirmLabel: "Delete Forever",
                          danger: true,
                          onConfirm: () => permanentDeleteUser(u.id),
                        })} className="p-1.5 rounded-lg text-gray-400 hover:text-red-600 hover:bg-red-50 transition-colors" title="Delete">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                        <button onClick={() => toggleUserExpand(u.id)}
                          className={`p-1.5 rounded-lg transition-colors ${isExpanded ? "bg-blue-100 text-blue-500" : "text-gray-300 hover:text-gray-500 hover:bg-gray-100"}`}
                          title="Expand details">
                          {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>

                    {/* Expand panel */}
                    {isExpanded && (
                      <div className="border-t border-blue-100 bg-blue-50/30 px-4 py-3 space-y-3">
                        <div className="flex flex-wrap gap-4">
                          <div>
                            <p className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide mb-1">Enrolled Courses</p>
                            {userCourses === undefined ? (
                              <p className="text-xs text-gray-400">Loading…</p>
                            ) : enrolledCourses!.length === 0 ? (
                              <p className="text-xs text-gray-400 italic">No courses enrolled</p>
                            ) : (
                              <div className="flex flex-wrap gap-1.5">
                                {enrolledCourses!.map(c => (
                                  <span key={c.id} className="text-xs px-2 py-0.5 rounded-full bg-white border border-gray-200 text-gray-700 font-medium">
                                    {c.title} <span className="text-gray-400">· Gr {c.grade}</span>
                                  </span>
                                ))}
                              </div>
                            )}
                          </div>
                          <div>
                            <p className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide mb-1">Last Login</p>
                            <p className="text-xs text-gray-700">
                              {lastLoginLog
                                ? new Date(lastLoginLog.createdAt).toLocaleString("en-IN", { day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" })
                                : <span className="italic text-gray-400">Never logged in</span>}
                            </p>
                          </div>
                          {u.role === "student" && mentorStudentMap[u.id] && !isEditing && (
                            <div>
                              <p className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide mb-1">Assigned Mentor</p>
                              <div className="flex items-center gap-1.5">
                                <div className="w-5 h-5 rounded-full flex items-center justify-center text-white text-[10px] font-black flex-shrink-0"
                                  style={{ background: "linear-gradient(135deg,#059669,#047857)" }}>
                                  {mentorStudentMap[u.id].mentorName.charAt(0).toUpperCase()}
                                </div>
                                <span className="text-xs text-gray-700 font-semibold">{mentorStudentMap[u.id].mentorName}</span>
                                {mentorStudentMap[u.id].mentorPhone && (
                                  <span className="text-xs text-green-600">· {mentorStudentMap[u.id].mentorPhone}</span>
                                )}
                              </div>
                            </div>
                          )}
                          {!isEditing && (
                            <div className="ml-auto self-start">
                              <button
                                onClick={() => { setInlineEditUserId(u.id); setInlineEditForm({ name: u.name, grade: String(u.grade ?? ""), school: u.school ?? "", email: u.email ?? "" }); }}
                                className="text-xs px-3 py-1.5 rounded-lg border border-blue-200 text-blue-500 hover:border-blue-400 hover:bg-blue-50 transition-colors flex items-center gap-1.5"
                              >
                                <Edit2 className="w-3 h-3" /> Edit
                              </button>
                            </div>
                          )}
                        </div>
                        {isEditing && (
                          <div className="bg-white rounded-xl border border-blue-200 p-4 space-y-3">
                            <p className="text-xs font-semibold text-gray-500">Quick Edit — {u.name}</p>
                            <div className="grid sm:grid-cols-2 gap-3">
                              <div>
                                <label className="text-[10px] text-gray-400 uppercase tracking-wide">Name *</label>
                                <Input value={inlineEditForm.name} onChange={e => setInlineEditForm(p => ({ ...p, name: e.target.value }))} className="mt-1 h-8 text-sm" />
                              </div>
                              <div>
                                <label className="text-[10px] text-gray-400 uppercase tracking-wide">Login Email</label>
                                <Input type="email" value={inlineEditForm.email} onChange={e => setInlineEditForm(p => ({ ...p, email: e.target.value }))} className="mt-1 h-8 text-sm" />
                              </div>
                              {u.role === "student" && (
                                <div>
                                  <label className="text-[10px] text-gray-400 uppercase tracking-wide">Grade</label>
                                  <Input type="number" min="0" max="10" value={inlineEditForm.grade} onChange={e => setInlineEditForm(p => ({ ...p, grade: e.target.value }))} className="mt-1 h-8 text-sm" />
                                </div>
                              )}
                              {u.role === "student" && (
                                <div>
                                  <label className="text-[10px] text-gray-400 uppercase tracking-wide">School</label>
                                  <Input value={inlineEditForm.school} onChange={e => setInlineEditForm(p => ({ ...p, school: e.target.value }))} className="mt-1 h-8 text-sm" />
                                </div>
                              )}
                            </div>
                            <div className="flex gap-2">
                              <Button size="sm" onClick={() => saveInlineEdit(u.id)} disabled={busy} className="h-7 text-xs text-white px-4" style={{ background: NAVY }}>
                                {busy ? "Saving…" : "Save"}
                              </Button>
                              <Button size="sm" variant="ghost" onClick={() => setInlineEditUserId(null)} className="h-7 text-xs px-3">Cancel</Button>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
              {!dataLoading && pagedUsers.length === 0 && (
                <div className="col-span-3 py-16 text-center">
                  <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-3">
                    <User className="w-6 h-6 text-gray-300" />
                  </div>
                  <div className="text-sm font-medium text-gray-400">No students found</div>
                  <div className="text-xs text-gray-300 mt-1">Try adjusting filters or search terms</div>
                </div>
              )}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-400">
                  Showing {(page - 1) * PAGE_SIZE + 1}–{Math.min(page * PAGE_SIZE, filteredUsers.length)} of {filteredUsers.length}
                </span>
                <div className="flex gap-1">
                  <Button size="sm" variant="outline" onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="text-xs">Prev</Button>
                  {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                    const p = Math.max(1, Math.min(totalPages - 4, page - 2)) + i;
                    return (
                      <Button key={p} size="sm" onClick={() => setPage(p)}
                        className={`text-xs w-8 h-8 p-0 ${p === page ? "text-white" : "variant-outline"}`}
                        style={p === page ? { background: ORANGE } : {}} variant={p === page ? "default" : "outline"}>
                        {p}
                      </Button>
                    );
                  })}
                  <Button size="sm" variant="outline" onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages} className="text-xs">Next</Button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ── Teacher Assignments ───────────────────────────────────────── */}
        {tab === "assignments" && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <p className="text-sm text-gray-500">Assign teachers to courses so they can manage content.</p>
              <Button size="sm" onClick={() => setShowAssignTeacher(true)} className="text-white gap-1.5" style={{ background: ORANGE }}>
                <Plus className="w-3.5 h-3.5" /> Assign
              </Button>
            </div>
            {showAssignTeacher && (
              <div className="bg-white rounded-2xl p-5 border border-orange-200 shadow-sm space-y-3">
                <h3 className="font-bold text-sm" style={{ color: NAVY }}>Assign Teacher to Course</h3>
                <div className="grid sm:grid-cols-2 gap-3">
                  <SearchableSelect
                    options={activeTeachers.map(t => ({ value: String(t.id), label: t.name }))}
                    value={assignForm.teacherId}
                    onValueChange={v => setAssignForm(p => ({ ...p, teacherId: v }))}
                    placeholder="Select Teacher (active only)"
                    searchPlaceholder="Search teachers…"
                  />
                  <SearchableSelect
                    options={courses.map(c => ({ value: String(c.id), label: `${c.title} (Gr ${c.grade}) · ${c.courseType ?? ""}` }))}
                    value={assignForm.courseId}
                    onValueChange={v => {
                      setAssignForm(p => ({ ...p, courseId: v, courseSubjectId: "" }));
                      loadSubjectsForAssign(v);
                    }}
                    placeholder="Select Course"
                    searchPlaceholder="Search courses…"
                  />
                  {assignCourseSubjects.length > 0 ? (
                    <SearchableSelect
                      options={[
                        { value: "__whole__", label: "Whole course (all subjects)" },
                        ...assignCourseSubjects.map(s => ({ value: String(s.id), label: s.name })),
                      ]}
                      value={assignForm.courseSubjectId || "__whole__"}
                      onValueChange={v => setAssignForm(p => ({ ...p, courseSubjectId: v === "__whole__" ? "" : v }))}
                      placeholder="Select Subject (optional)"
                      searchPlaceholder="Search subjects…"
                    />
                  ) : assignForm.courseId ? (
                    <div className="flex items-center text-xs text-amber-600 bg-amber-50 rounded-lg px-3 py-2">
                      ⚠ No subjects in this course — will assign the whole course.
                    </div>
                  ) : <div />}
                </div>
                <div className="flex gap-2">
                  <Button size="sm" onClick={assignTeacher} disabled={busy || !assignForm.teacherId || !assignForm.courseId} className="text-white" style={{ background: ORANGE }}>Assign</Button>
                  <Button size="sm" variant="ghost" onClick={() => setShowAssignTeacher(false)}>Cancel</Button>
                </div>
              </div>
            )}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-auto">
              <table className="w-full text-sm">
                <thead><tr className="border-b border-gray-100" style={{ background: "#F8FAFF" }}>
                  <th className="text-left px-4 py-3 font-semibold text-gray-500 text-xs">Teacher</th>
                  <th className="text-left px-4 py-3 font-semibold text-gray-500 text-xs">Course</th>
                  <th className="text-left px-4 py-3 font-semibold text-gray-500 text-xs">Assigned</th>
                  <th className="px-4 py-3" />
                </tr></thead>
                <tbody>
                  {assignments.map(a => (
                    <tr key={a.id} className="border-b border-gray-50 hover:bg-gray-50">
                      <td className="px-4 py-3 font-medium" style={{ color: NAVY }}>{a.teacherName}</td>
                      <td className="px-4 py-3 text-gray-600">{a.courseTitle}</td>
                      <td className="px-4 py-3 text-gray-400 text-xs">{new Date(a.assignedAt).toLocaleDateString("en-IN")}</td>
                      <td className="px-4 py-3">
                        <button onClick={() => confirm({ title: "Remove Assignment", message: `Remove ${a.teacherName} from ${a.courseTitle}?`, confirmLabel: "Remove", danger: true, onConfirm: () => removeAssignment(a.id) })}
                          className="text-red-400 hover:text-red-600"><Trash2 className="w-4 h-4" /></button>
                      </td>
                    </tr>
                  ))}
                  {assignments.length === 0 && <tr><td colSpan={4} className="px-4 py-8 text-center text-gray-400 text-sm">No assignments yet</td></tr>}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ── Enrollments ───────────────────────────────────────────────── */}
        {tab === "enrollments" && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <p className="text-sm text-gray-500">Enroll students into courses.</p>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={exportEnrollmentsCSV} className="gap-1.5 text-xs">
                  <Download className="w-3.5 h-3.5" /> Export CSV
                </Button>
                <Button size="sm" onClick={() => setShowEnrollStudent(true)} className="text-white gap-1.5" style={{ background: ORANGE }}>
                  <Plus className="w-3.5 h-3.5" /> Enroll
                </Button>
              </div>
            </div>
            {showEnrollStudent && (
              <div className="bg-white rounded-2xl p-5 border border-orange-200 shadow-sm space-y-3">
                <h3 className="font-bold text-sm" style={{ color: NAVY }}>Enroll Student in Course</h3>
                <div className="grid sm:grid-cols-2 gap-3">
                  <SearchableSelect
                    options={students.map(s => ({ value: String(s.id), label: `${s.name} (Gr ${s.grade})` }))}
                    value={enrollForm.studentId}
                    onValueChange={v => setEnrollForm(p => ({ ...p, studentId: v }))}
                    placeholder="Select Student"
                    searchPlaceholder="Search students…"
                  />
                  <SearchableSelect
                    options={courses.map(c => ({ value: String(c.id), label: `#${c.id} ${c.title} · Gr ${c.grade}` }))}
                    value={enrollForm.courseId}
                    onValueChange={v => setEnrollForm(p => ({ ...p, courseId: v }))}
                    placeholder="Select Course"
                    searchPlaceholder="Search by name or ID…"
                  />
                </div>
                <div className="flex gap-2">
                  <Button size="sm" onClick={enrollStudent} disabled={busy || !enrollForm.studentId || !enrollForm.courseId} className="text-white" style={{ background: ORANGE }}>Enroll</Button>
                  <Button size="sm" variant="ghost" onClick={() => setShowEnrollStudent(false)}>Cancel</Button>
                </div>
              </div>
            )}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-auto">
              <table className="w-full text-sm">
                <thead><tr className="border-b border-gray-100" style={{ background: "#F8FAFF" }}>
                  <th className="text-left px-4 py-3 font-semibold text-gray-500 text-xs">Student</th>
                  <th className="text-left px-4 py-3 font-semibold text-gray-500 text-xs">Course</th>
                  <th className="text-left px-4 py-3 font-semibold text-gray-500 text-xs">Enrolled</th>
                  <th className="px-4 py-3" />
                </tr></thead>
                <tbody>
                  {enrollments.map(e => (
                    <tr key={e.id} className="border-b border-gray-50 hover:bg-gray-50">
                      <td className="px-4 py-3 font-medium" style={{ color: NAVY }}>{e.studentName}</td>
                      <td className="px-4 py-3 text-gray-600">{e.courseTitle}</td>
                      <td className="px-4 py-3 text-gray-400 text-xs">{new Date(e.enrolledAt).toLocaleDateString("en-IN")}</td>
                      <td className="px-4 py-3">
                        <button onClick={() => confirm({ title: "Remove Enrollment", message: `Remove ${e.studentName} from ${e.courseTitle}?`, confirmLabel: "Remove", danger: true, onConfirm: () => removeEnrollment(e.id, e.studentId) })}
                          className="text-red-400 hover:text-red-600"><Trash2 className="w-4 h-4" /></button>
                      </td>
                    </tr>
                  ))}
                  {enrollments.length === 0 && <tr><td colSpan={4} className="px-4 py-8 text-center text-gray-400 text-sm">No enrollments yet</td></tr>}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ── Announcements ─────────────────────────────────────────────── */}
        {tab === "announcements" && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <p className="text-sm text-gray-500">Broadcast messages to students or teachers.</p>
              <Button size="sm" onClick={() => setShowAnnForm(!showAnnForm)} className="text-white gap-1.5" style={{ background: ORANGE }}>
                <Plus className="w-3.5 h-3.5" /> New Announcement
              </Button>
            </div>

            {showAnnForm && (
              <div className="bg-white rounded-2xl p-5 border border-orange-200 shadow-sm space-y-3">
                <h3 className="font-bold text-sm" style={{ color: NAVY }}>Create Announcement</h3>
                <div className="grid sm:grid-cols-2 gap-3">
                  <Input placeholder="Title *" value={annForm.title} onChange={e => setAnnForm(p => ({ ...p, title: e.target.value }))} className="sm:col-span-2" />
                  <Textarea placeholder="Body *" value={annForm.body} onChange={e => setAnnForm(p => ({ ...p, body: e.target.value }))} rows={3} className="sm:col-span-2" />
                  <Select value={annForm.targetRole} onValueChange={v => setAnnForm(p => ({ ...p, targetRole: v }))}>
                    <SelectTrigger><SelectValue placeholder="Target audience" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Everyone</SelectItem>
                      <SelectItem value="student">Students</SelectItem>
                      <SelectItem value="teacher">Teachers</SelectItem>
                    </SelectContent>
                  </Select>
                  <Input placeholder="Grade filter (optional)" type="number" min="1" max="10" value={annForm.grade} onChange={e => setAnnForm(p => ({ ...p, grade: e.target.value }))} />
                </div>
                <div className="flex gap-2">
                  <Button size="sm" onClick={createAnnouncement} disabled={busy || !annForm.title || !annForm.body} className="text-white" style={{ background: ORANGE }}>Publish</Button>
                  <Button size="sm" variant="ghost" onClick={() => setShowAnnForm(false)}>Cancel</Button>
                </div>
              </div>
            )}

            <div className="space-y-3">
              {announcements.map(a => (
                <div key={a.id} className={`bg-white rounded-2xl p-4 shadow-sm border ${a.isActive ? "border-gray-100" : "border-gray-200 opacity-60"}`}>
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-sm" style={{ color: NAVY }}>{a.title}</span>
                        <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${a.isActive ? "bg-green-100 text-green-600" : "bg-gray-100 text-gray-400"}`}>{a.isActive ? "Active" : "Inactive"}</span>
                        <span className="text-xs bg-blue-50 text-blue-600 px-2 py-0.5 rounded-full">{a.targetRole}</span>
                        {a.grade && <span className="text-xs bg-purple-50 text-purple-600 px-2 py-0.5 rounded-full">Grade {a.grade}</span>}
                      </div>
                      <p className="text-sm text-gray-600 mt-1 line-clamp-2">{a.body}</p>
                      <p className="text-xs text-gray-400 mt-1">{new Date(a.createdAt).toLocaleDateString("en-IN")}</p>
                    </div>
                    <div className="flex gap-1 flex-shrink-0">
                      <button onClick={() => toggleAnnouncement(a)} className="text-xs px-2 py-1 rounded-lg border hover:bg-gray-50 transition-colors text-gray-500">{a.isActive ? "Hide" : "Show"}</button>
                      <button onClick={() => confirm({ title: "Delete Announcement", message: `Delete "${a.title}"?`, confirmLabel: "Delete", danger: true, onConfirm: () => deleteAnnouncement(a.id) })}
                        className="text-red-400 hover:text-red-600 transition-colors p-1"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  </div>
                </div>
              ))}
              {announcements.length === 0 && !showAnnForm && (
                <div className="py-12 text-center"><Bell className="w-8 h-8 text-gray-300 mx-auto mb-2" /><p className="text-gray-400 text-sm">No announcements yet</p></div>
              )}
            </div>
          </div>
        )}

        {/* ── Live Classes ──────────────────────────────────────────────── */}
        {tab === "liveclasses" && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-base" style={{ color: NAVY }}>Live Class Schedule</h3>
                <p className="text-xs text-gray-400 mt-0.5">Schedule classes, assign teachers, and set join links</p>
              </div>
              <Button size="sm" onClick={() => setShowLcForm(!showLcForm)} className="text-white gap-1.5" style={{ background: ORANGE }}>
                <Plus className="w-3.5 h-3.5" /> Schedule Class
              </Button>
            </div>

            {showLcForm && (
              <div className="bg-white rounded-2xl p-5 border border-orange-200 shadow-sm space-y-3">
                <h3 className="font-bold text-sm" style={{ color: NAVY }}>New Live Class</h3>
                <p className="text-xs text-gray-400">Select Course → Subject → Chapter → Topic to link this class to the right place in the curriculum.</p>
                <div className="grid sm:grid-cols-2 gap-3">
                  <Input placeholder="Class title *" value={lcForm.title} onChange={e => setLcForm(p => ({ ...p, title: e.target.value }))} className="sm:col-span-2" />

                  {/* Step 1: Course */}
                  <div className="sm:col-span-2 space-y-1.5">
                    <SearchableSelect
                      options={[
                        { value: "__none__", label: "No course" },
                        ...courses.map(c => ({ value: String(c.id), label: `#${c.id} ${c.title} · Gr ${c.grade}` })),
                      ]}
                      value={lcForm.courseId || "__none__"}
                      onValueChange={v => {
                        const val = v === "__none__" ? "" : v;
                        const course = val ? courses.find(c => String(c.id) === val) : null;
                        setLcForm(p => ({ ...p, courseId: val, courseSubjectId: "", chapterId: "", topicId: "", grade: course ? String(course.grade) : p.grade, title: !p.title && course ? course.title : p.title }));
                        setLcCourseSubjects([]);
                        setLcChapters([]);
                        setLcTopics([]);
                        loadSubjectsForCourse(val);
                      }}
                      placeholder="① Select Course *"
                      searchPlaceholder="Search by name or ID…"
                    />
                    {lcForm.courseId && (
                      <p className="text-xs text-green-600 font-medium">✓ Course #{lcForm.courseId} selected</p>
                    )}
                  </div>

                  {/* Step 2: Subject */}
                  {lcCourseSubjects.length > 0 ? (
                    <SearchableSelect
                      options={[
                        { value: "__none__", label: "No subject" },
                        ...lcCourseSubjects.map(s => ({ value: String(s.id), label: s.name })),
                      ]}
                      value={lcForm.courseSubjectId || "__none__"}
                      onValueChange={v => {
                        const val = v === "__none__" ? "" : v;
                        setLcForm(p => ({ ...p, courseSubjectId: val, chapterId: "", topicId: "" }));
                        setLcChapters([]);
                        setLcTopics([]);
                        loadChaptersForSubject(val);
                      }}
                      placeholder="② Select Subject"
                      searchPlaceholder="Search subjects…"
                    />
                  ) : lcForm.courseId ? (
                    <div className="flex items-center text-xs text-amber-600 bg-amber-50 rounded-lg px-3 py-2">
                      ⚠ No subjects in this course yet — add them in Course Management first.
                    </div>
                  ) : <div />}

                  {/* Step 3: Chapter */}
                  {lcChapters.length > 0 ? (
                    <SearchableSelect
                      options={[
                        { value: "__none__", label: "No chapter" },
                        ...lcChapters.map(c => ({ value: String(c.id), label: c.name })),
                      ]}
                      value={lcForm.chapterId || "__none__"}
                      onValueChange={v => {
                        const val = v === "__none__" ? "" : v;
                        setLcForm(p => ({ ...p, chapterId: val, topicId: "" }));
                        setLcTopics([]);
                        loadTopicsForChapter(val);
                      }}
                      placeholder="③ Select Chapter"
                      searchPlaceholder="Search chapters…"
                    />
                  ) : lcForm.courseSubjectId ? (
                    <div className="flex items-center text-xs text-amber-600 bg-amber-50 rounded-lg px-3 py-2">
                      ⚠ No chapters in this subject yet.
                    </div>
                  ) : <div />}

                  {/* Step 4: Topic */}
                  {lcTopics.length > 0 ? (
                    <SearchableSelect
                      options={[
                        { value: "__none__", label: "No topic" },
                        ...lcTopics.map(t => ({ value: String(t.id), label: t.name })),
                      ]}
                      value={lcForm.topicId || "__none__"}
                      onValueChange={v => setLcForm(p => ({ ...p, topicId: v === "__none__" ? "" : v }))}
                      placeholder="④ Select Topic"
                      searchPlaceholder="Search topics…"
                    />
                  ) : lcForm.chapterId ? (
                    <div className="flex items-center text-xs text-amber-600 bg-amber-50 rounded-lg px-3 py-2">
                      ⚠ No topics in this chapter yet.
                    </div>
                  ) : <div />}

                  {/* Grade — auto-filled by course, or manual if no course */}
                  <Input
                    placeholder="Grade (1–10) *"
                    type="number" min="1" max="10"
                    value={lcForm.grade}
                    onChange={e => setLcForm(p => ({ ...p, grade: e.target.value }))}
                    readOnly={!!lcForm.courseId}
                    className={lcForm.courseId ? "bg-gray-50" : ""}
                  />

                  <SearchableSelect
                    options={[
                      { value: "none", label: "No specific teacher" },
                      ...activeTeachers.map(t => ({ value: String(t.id), label: t.name })),
                    ]}
                    value={lcForm.teacherId || "none"}
                    onValueChange={v => {
                      const name = v !== "none" ? (activeTeachers.find(t => String(t.id) === v)?.name ?? "") : "";
                      setLcForm(p => ({ ...p, teacherId: v, teacher: name }));
                    }}
                    placeholder="Assign teacher (active only)"
                    searchPlaceholder="Search teachers…"
                  />
                  <Input type="datetime-local" value={lcForm.scheduledAt} onChange={e => setLcForm(p => ({ ...p, scheduledAt: e.target.value }))} />
                  <Input placeholder="Duration (minutes)" type="number" min="15" value={lcForm.duration} onChange={e => setLcForm(p => ({ ...p, duration: e.target.value }))} />
                  <p className="text-xs text-gray-400 sm:col-span-2">A live class room is created automatically — no meeting link needed.</p>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" onClick={createLiveClass}
                    disabled={busy || !lcForm.title || !lcForm.scheduledAt || (!lcForm.grade && !lcForm.courseId)}
                    className="text-white" style={{ background: ORANGE }}>Schedule</Button>
                  <Button size="sm" variant="ghost" onClick={() => { setShowLcForm(false); setLcCourseSubjects([]); setLcChapters([]); setLcTopics([]); }}>Cancel</Button>
                </div>
              </div>
            )}

            <div className="grid grid-cols-3 gap-3">
              {[
                { label: "Total", value: liveClassItems.length, color: NAVY },
                { label: "Live Now", value: liveClassItems.filter(l => l.status === "live").length, color: "#EF4444" },
                { label: "Upcoming", value: liveClassItems.filter(l => l.status === "upcoming").length, color: "#22C55E" },
              ].map(s => (
                <div key={s.label} className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 text-center">
                  <div className="text-2xl font-black" style={{ color: s.color }}>{s.value}</div>
                  <div className="text-xs text-gray-500 font-medium mt-0.5">{s.label}</div>
                </div>
              ))}
            </div>

            <div className="space-y-3">
              {liveClassItems.map(lc => (
                <div key={lc.id} className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
                  <div className="flex items-start justify-between gap-3 flex-wrap">
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                        style={{ background: lc.status === "live" ? "#FEE2E2" : lc.status === "upcoming" ? "#DCFCE7" : "#F3F4F6" }}>
                        <Video className="w-5 h-5" style={{ color: lc.status === "live" ? "#EF4444" : lc.status === "upcoming" ? "#22C55E" : "#9CA3AF" }} />
                      </div>
                      <div className="min-w-0">
                        <div className="font-semibold text-sm truncate" style={{ color: NAVY }}>{lc.title}</div>
                        <div className="text-xs text-gray-400 mt-0.5">{lc.subjectName} · Grade {lc.grade} · {lc.teacher}</div>
                        <div className="flex items-center gap-3 mt-1 text-xs text-gray-400">
                          <span className="flex items-center gap-1"><Calendar className="w-3 h-3" />{new Date(lc.scheduledAt).toLocaleString("en-IN", { timeZone: "Asia/Kolkata", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}</span>
                          <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{lc.duration} min</span>
                        </div>
                        <div className="flex items-center gap-2 mt-1.5">
                          <a href={`/live/${lc.id}?role=admin&title=${encodeURIComponent(lc.title)}`} target="_blank" rel="noopener noreferrer"
                            className="text-xs flex items-center gap-1 text-blue-500 hover:text-blue-700">
                            <LinkIcon className="w-3 h-3 flex-shrink-0" /><span>Enter Live Room</span>
                          </a>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <span className={`text-xs px-2 py-1 rounded-full font-semibold ${lc.status === "live" ? "bg-red-100 text-red-600" : lc.status === "upcoming" ? "bg-green-100 text-green-600" : "bg-gray-100 text-gray-500"}`}>
                        {lc.status === "live" ? "🔴 Live" : lc.status === "upcoming" ? "🟢 Upcoming" : "⚫ Ended"}
                      </span>
                      <Select value={lc.status} onValueChange={v => updateLiveClassStatus(lc.id, v)}>
                        <SelectTrigger className="h-8 text-xs w-28 border-gray-200"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="upcoming">Upcoming</SelectItem>
                          <SelectItem value="live">Go Live</SelectItem>
                          <SelectItem value="ended">End Class</SelectItem>
                        </SelectContent>
                      </Select>
                      <button
                        onClick={() => {
                          setEditingLcFull({
                            id: lc.id,
                            title: lc.title,
                            teacher: lc.teacher,
                            grade: String(lc.grade),
                            scheduledAt: (() => { const d = new Date(lc.scheduledAt); const ist = new Date(d.getTime() + 5.5*60*60*1000); const p = (n: number) => String(n).padStart(2,"0"); return `${ist.getUTCFullYear()}-${p(ist.getUTCMonth()+1)}-${p(ist.getUTCDate())}T${p(ist.getUTCHours())}:${p(ist.getUTCMinutes())}`; })(),
                            duration: String(lc.duration),
                          });
                        }}
                        className="text-blue-400 hover:text-blue-600 transition-colors p-1" title="Edit">
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button onClick={() => confirm({ title: "Delete Live Class", message: `Delete "${lc.title}"?`, confirmLabel: "Delete", danger: true, onConfirm: () => deleteLiveClass(lc.id) })}
                        className="text-red-400 hover:text-red-600 transition-colors p-1"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  </div>

                  {/* ── Full edit form ── */}
                  {editingLcFull?.id === lc.id && (
                    <div className="mt-4 pt-4 border-t border-gray-100 grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <Input
                        className="sm:col-span-2 h-8 text-xs"
                        placeholder="Title *"
                        value={editingLcFull.title}
                        onChange={e => setEditingLcFull(p => p && ({ ...p, title: e.target.value }))}
                      />
                      <Input
                        className="h-8 text-xs"
                        placeholder="Teacher name *"
                        value={editingLcFull.teacher}
                        onChange={e => setEditingLcFull(p => p && ({ ...p, teacher: e.target.value }))}
                      />
                      <Input
                        className="h-8 text-xs"
                        placeholder="Grade (1–10)"
                        type="number" min="1" max="10"
                        value={editingLcFull.grade}
                        onChange={e => setEditingLcFull(p => p && ({ ...p, grade: e.target.value }))}
                      />
                      <Input
                        className="h-8 text-xs"
                        type="datetime-local"
                        value={editingLcFull.scheduledAt}
                        onChange={e => setEditingLcFull(p => p && ({ ...p, scheduledAt: e.target.value }))}
                      />
                      <Input
                        className="h-8 text-xs"
                        placeholder="Duration (minutes)"
                        type="number" min="15"
                        value={editingLcFull.duration}
                        onChange={e => setEditingLcFull(p => p && ({ ...p, duration: e.target.value }))}
                      />
                      <div className="sm:col-span-2 flex gap-2">
                        <Button size="sm" className="h-7 text-xs text-white px-4" style={{ background: NAVY }}
                          disabled={busy || !editingLcFull.title || !editingLcFull.teacher}
                          onClick={updateLiveClassFull}>Save Changes</Button>
                        <Button size="sm" variant="ghost" className="h-7 text-xs"
                          onClick={() => setEditingLcFull(null)}>Cancel</Button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
              {liveClassItems.length === 0 && !showLcForm && (
                <div className="py-16 text-center">
                  <Video className="w-10 h-10 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-400 font-medium">No live classes scheduled</p>
                  <p className="text-xs text-gray-300 mt-1">Click "Schedule Class" to create your first session</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ── Banners ───────────────────────────────────────────────────── */}
        {tab === "banners" && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <p className="text-sm text-gray-500">Manage promotional banners shown on the dashboard.</p>
              <Button size="sm" onClick={() => setShowBannerForm(!showBannerForm)} className="text-white gap-1.5" style={{ background: ORANGE }}>
                <Plus className="w-3.5 h-3.5" /> Add Banner
              </Button>
            </div>

            {showBannerForm && (
              <div className="bg-white rounded-2xl p-5 border border-orange-200 shadow-sm space-y-3">
                <h3 className="font-bold text-sm" style={{ color: NAVY }}>New Banner</h3>
                <div className="grid sm:grid-cols-2 gap-3">
                  <Input placeholder="Title *" value={bannerForm.title} onChange={e => setBannerForm(p => ({ ...p, title: e.target.value }))} />
                  <Input placeholder="Image URL *" value={bannerForm.imageUrl} onChange={e => setBannerForm(p => ({ ...p, imageUrl: e.target.value }))} />
                  <Input placeholder="Link (optional)" value={bannerForm.link} onChange={e => setBannerForm(p => ({ ...p, link: e.target.value }))} />
                  <Input placeholder="Display order" type="number" value={bannerForm.displayOrder} onChange={e => setBannerForm(p => ({ ...p, displayOrder: e.target.value }))} />
                </div>
                {bannerForm.imageUrl && (
                  <img src={bannerForm.imageUrl} alt="Preview" className="w-full h-32 object-cover rounded-xl border border-gray-200" onError={e => (e.currentTarget.style.display = "none")} />
                )}
                <div className="flex gap-2">
                  <Button size="sm" onClick={createBanner} disabled={busy || !bannerForm.title || !bannerForm.imageUrl} className="text-white" style={{ background: ORANGE }}>Save</Button>
                  <Button size="sm" variant="ghost" onClick={() => setShowBannerForm(false)}>Cancel</Button>
                </div>
              </div>
            )}

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {banners.map(b => (
                <div key={b.id} className={`bg-white rounded-2xl shadow-sm border overflow-hidden ${!b.isActive ? "opacity-60" : "border-gray-100"}`}>
                  <img src={b.imageUrl} alt={b.title} className="w-full h-36 object-cover"
                    onError={e => { (e.currentTarget as HTMLImageElement).src = `https://placehold.co/400x200/0B2B6B/white?text=${encodeURIComponent(b.title)}`; }} />
                  <div className="p-3">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-sm" style={{ color: NAVY }}>{b.title}</span>
                      <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${b.isActive ? "bg-green-100 text-green-600" : "bg-gray-100 text-gray-400"}`}>{b.isActive ? "Live" : "Off"}</span>
                    </div>
                    {b.link && <p className="text-xs text-gray-400 mt-0.5 truncate">{b.link}</p>}
                    <div className="flex gap-2 mt-2">
                      <button onClick={() => toggleBanner(b)} className="flex-1 text-xs py-1.5 rounded-lg border hover:bg-gray-50 transition-colors text-gray-500">
                        {b.isActive ? "Disable" : "Enable"}
                      </button>
                      <button onClick={() => confirm({ title: "Delete Banner", message: `Delete "${b.title}"?`, confirmLabel: "Delete", danger: true, onConfirm: () => deleteBanner(b.id) })}
                        className="px-3 py-1.5 rounded-lg bg-red-50 text-red-400 hover:bg-red-100 transition-colors text-xs"><Trash2 className="w-3.5 h-3.5" /></button>
                    </div>
                  </div>
                </div>
              ))}
              {banners.length === 0 && !showBannerForm && (
                <div className="col-span-3 py-12 text-center"><Image className="w-8 h-8 text-gray-300 mx-auto mb-2" /><p className="text-gray-400 text-sm">No banners yet</p></div>
              )}
            </div>
          </div>
        )}

        {/* ── Audit Logs ─────────────────────────────────────────────────── */}
        {tab === "audit" && <AuditLogsTab />}

        {/* ── Payments ─────────────────────────────────────────────────── */}
        {tab === "payments" && <PaymentsTab />}

        {/* ── Ignite (Sales & Admissions) CRM ──────────────────────────── */}
        {tab === "ignite" && (
          <IgniteContentArea view={igniteView} setView={setIgniteView} flash={flash} role={role} />
        )}

        {/* ── Command Center ───────────────────────────────────────────── */}
        {tab === "command-center" && <CommandCenterTab />}

        {/* ── BTL CRM ──────────────────────────────────────────────────── */}
        {tab === "btl-crm" && <BtlCrmTab users={users} />}

        {/* ── Mentors ──────────────────────────────────────────────────── */}
        {tab === "mentors" && <MentorsTab flash={flash} users={users} />}

        {/* ── Staff Attendance ─────────────────────────────────────────── */}
        {tab === "employee-attendance" && <EmployeeAttendanceTab />}

        {/* ── Operations Command Center ─────────────────────────────────── */}
        {tab === "operations-command-center" && <OperationsCommandCenterTab />}

        {/* ── Super Admin Console ───────────────────────────────────────── */}
        {tab === "super-admin" && <SuperAdminTab flash={flash} role={role ?? undefined} />}

        {/* ── Dashboard ────────────────────────────────────────────────── */}
        {tab === "dashboard" && <DashboardTab />}

        {/* ── Course Analytics ─────────────────────────────────────────── */}
        {tab === "course-analytics" && <CourseAnalyticsTab />}

        {/* ── Teachers ─────────────────────────────────────────────────── */}
        {tab === "teacher-analytics" && <TeacherAnalyticsTab flash={flash} />}

        {/* ── Learning Health ───────────────────────────────────────────── */}
        {tab === "health" && <HealthTab onViewStudents={() => setTab("mastery-students")} />}

        {/* ── Assessments ──────────────────────────────────────────────── */}
        {tab === "assessments" && <AssessmentsTab flash={flash} />}

        {/* ── Reports & Analytics ──────────────────────────────────────── */}
        {tab === "reports-analytics" && <ReportsAnalyticsTab />}

        {/* ── Mastery Students ─────────────────────────────────────────── */}
        {tab === "mastery-students" && <MasteryStudentsTab flash={flash} role={role} />}

        {/* ── Mastery Payment Verification ─────────────────────────────── */}
        {tab === "mastery-payments"    && <MasteryPaymentVerificationTab />}
        {tab === "mastery-deployment" && <MasteryDeploymentTab />}
        {tab === "mastery-retention"  && <MasteryRetentionTab />}
        {tab === "mastery-attendance" && <MasteryAttendanceAnalyticsTab />}

        {/* ── Gamification ─────────────────────────────────────────────── */}
        {tab === "gamification" && <GamificationTab />}

        {/* ── Chat Moderation — Blocked Words ───────────────────────────── */}
        {tab === "blocked-words" && <BlockedWordsTab />}

        {/* ── Settings ─────────────────────────────────────────────────── */}
        {tab === "settings" && (
          <div className="space-y-5 max-w-2xl">
            <h3 className="font-bold text-base" style={{ color: NAVY }}>Settings & Account</h3>

            {/* Admin own profile + password */}
            <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center flex-shrink-0">
                  <Shield className="w-5 h-5 text-orange-600" />
                </div>
                <div>
                  <div className="font-semibold text-sm">{student?.name}</div>
                  <div className="text-xs text-gray-400">{student?.email ?? "No email"} · Administrator</div>
                </div>
              </div>
              <div className="h-px bg-gray-100" />
              <ChangePasswordForm flash={flash} />
            </div>

            {/* Staff quick stats */}
            <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
              <div className="flex items-center gap-2 mb-4">
                <Users className="w-4 h-4" style={{ color: NAVY }} />
                <h4 className="font-semibold text-sm" style={{ color: NAVY }}>Staff Overview</h4>
              </div>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { role: "teacher", label: "Teachers", color: "#3B82F6", bg: "#EFF6FF" },
                  { role: "mentor",  label: "Mentors",  color: "#059669", bg: "#ECFDF5" },
                  { role: "admin",   label: "Admins",   color: "#8B5CF6", bg: "#F5F3FF" },
                ].map(({ role, label, color, bg }) => {
                  const count = users.filter(u => u.role === role && u.isActive).length;
                  const inactive = users.filter(u => u.role === role && !u.isActive).length;
                  return (
                    <div key={role} className="rounded-xl p-3 text-center" style={{ background: bg }}>
                      <div className="text-2xl font-black" style={{ color }}>{count}</div>
                      <div className="text-xs font-semibold text-gray-600">{label}</div>
                      {inactive > 0 && <div className="text-[10px] text-gray-400">{inactive} inactive</div>}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Reset any user / teacher / mentor password */}
            <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm space-y-4">
              <div className="flex items-center gap-2">
                <Key className="w-4 h-4" style={{ color: NAVY }} />
                <h4 className="font-semibold text-sm" style={{ color: NAVY }}>Reset Staff or Student Password</h4>
              </div>
              <p className="text-xs text-gray-400">Search any teacher, mentor, or student and reset their password directly. Admins excluded for security.</p>
              <AdminUserPasswordReset users={users} flash={flash} />
            </div>

            {/* Platform info */}
            <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
              <div className="flex items-center gap-2 mb-4">
                <Activity className="w-4 h-4" style={{ color: NAVY }} />
                <h4 className="font-semibold text-sm" style={{ color: NAVY }}>Platform Info</h4>
              </div>
              <div className="space-y-2.5">
                {[
                  { label: "Platform", value: "Braintam EdTech LMS" },
                  { label: "Target", value: "School students, Grades 1–10" },
                  { label: "Stack", value: "React + Vite · Express 5 · PostgreSQL · Drizzle ORM" },
                  { label: "Auth (Students)", value: "Clerk — Google OAuth + Email/Password" },
                  { label: "Auth (Staff)", value: "Custom email/password with hashed tokens" },
                  { label: "Version", value: "2026.1" },
                ].map(({ label, value }) => (
                  <div key={label} className="flex items-start justify-between gap-4 py-2 border-b border-gray-50 last:border-0">
                    <span className="text-xs font-semibold text-gray-500 flex-shrink-0">{label}</span>
                    <span className="text-xs text-gray-700 text-right">{value}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Total students by grade (quick view) */}
            <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
              <div className="flex items-center gap-2 mb-4">
                <GraduationCap className="w-4 h-4" style={{ color: NAVY }} />
                <h4 className="font-semibold text-sm" style={{ color: NAVY }}>Student Grades at a Glance</h4>
              </div>
              <div className="flex flex-wrap gap-2">
                {Array.from({ length: 10 }, (_, i) => i + 1).map(g => {
                  const count = users.filter(u => isMasteryStudent(u) && u.isActive && u.grade === g).length;
                  return (
                    <div key={g} className="flex flex-col items-center justify-center rounded-xl px-3 py-2 min-w-[52px]"
                      style={{ background: count > 0 ? "#EEF2FF" : "#F9FAFB" }}>
                      <span className="text-base font-black" style={{ color: count > 0 ? NAVY : "#D1D5DB" }}>{count}</span>
                      <span className="text-[10px] text-gray-400">Gr {g}</span>
                    </div>
                  );
                })}
              </div>
              <p className="text-[10px] text-gray-400 mt-3">Only active students shown. Go to Dashboard → Class/Grade Wise for full breakdown.</p>
            </div>
          </div>
        )}

        {/* ── My Profile ── */}
        {tab === "profile" && (
          <div className="space-y-2">
            <h3 className="font-bold text-base" style={{ color: NAVY }}>My Profile</h3>
            <StaffProfileTab
              user={{
                id: student.id,
                name: student.name ?? "",
                email: student.email ?? null,
                phone: student.phone ?? null,
                role: role ?? "admin",
                avatarUrl: student.avatarUrl,
                school: student.school,
              }}
              apiFetch={apiFetch}
              flash={flash}
            />
          </div>
        )}
      </div>
      </div>
      </div>
    </div>
  );
}

// ── Admin: Reset Any User Password ─────────────────────────────────────────
function AdminUserPasswordReset({ users, flash }: { users: User[]; flash: (msg: string, ok?: boolean) => void }) {
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<User | null>(null);
  const [newPw, setNewPw] = useState("");
  const [busy, setBusy] = useState(false);

  const filtered = useMemo(() => {
    if (!search.trim()) return [];
    const q = search.toLowerCase();
    return users
      .filter(u => u.role !== "admin" && u.role !== "super_admin")
      .filter(u =>
        u.name.toLowerCase().includes(q) ||
        (u.email ?? "").toLowerCase().includes(q) ||
        (u.phone ?? "").includes(q)
      )
      .slice(0, 8);
  }, [users, search]);

  async function resetPw() {
    if (!selected || !newPw || newPw.length < 6) return;
    setBusy(true);
    const r = await apiFetch(`/admin/users/${selected.id}/reset-password`, {
      method: "POST",
      body: JSON.stringify({ password: newPw }),
    });
    setBusy(false);
    if (r.ok) {
      flash(`Password reset for ${selected.name}!`);
      setNewPw(""); setSelected(null); setSearch("");
    } else {
      const d = await r.json().catch(() => ({}));
      flash(d.error ?? "Failed to reset password", false);
    }
  }

  return (
    <div className="space-y-3">
      <div className="relative">
        <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
        <Input
          placeholder="Search teacher or student by name / email…"
          value={search}
          onChange={e => { setSearch(e.target.value); setSelected(null); }}
          className="pl-9 text-sm"
        />
      </div>
      {filtered.length > 0 && !selected && (
        <div className="border border-gray-100 rounded-xl overflow-hidden shadow-sm">
          {filtered.map(u => (
            <button
              key={u.id}
              onClick={() => { setSelected(u); setSearch(u.name); }}
              className="w-full flex items-center gap-3 px-3 py-2.5 hover:bg-gray-50 text-left border-b border-gray-50 last:border-0"
            >
              <div className="w-7 h-7 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0" style={{ background: NAVY }}>{u.name[0]}</div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium truncate" style={{ color: NAVY }}>{u.name}</div>
                <div className="text-xs text-gray-400 truncate">{u.email ?? u.phone ?? "—"} · {u.role}</div>
              </div>
            </button>
          ))}
        </div>
      )}
      {selected && (
        <div className="space-y-2">
          <div className="flex items-center gap-2 bg-blue-50 rounded-xl px-3 py-2.5">
            <div className="w-7 h-7 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0" style={{ background: NAVY }}>{selected.name[0]}</div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-semibold" style={{ color: NAVY }}>{selected.name}</div>
              <div className="text-xs text-gray-500">{selected.email ?? selected.phone} · {selected.role}</div>
            </div>
            <button onClick={() => { setSelected(null); setSearch(""); }} className="text-gray-400 hover:text-gray-600"><X className="w-4 h-4" /></button>
          </div>
          <Input
            type="password"
            placeholder="New password (min 6 chars)"
            value={newPw}
            onChange={e => setNewPw(e.target.value)}
          />
          <Button size="sm" onClick={resetPw} disabled={busy || !newPw || newPw.length < 6} className="text-white" style={{ background: ORANGE }}>
            {busy ? "Resetting…" : `Reset Password for ${selected.name}`}
          </Button>
        </div>
      )}
    </div>
  );
}

// ── Change Password Form ───────────────────────────────────────────────────
function ChangePasswordForm({ flash }: { flash: (msg: string, ok?: boolean) => void }) {
  const [currentPw, setCurrentPw] = useState("");
  const [newPw, setNewPw] = useState("");
  const [confirmPw, setConfirmPw] = useState("");
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [busy, setBusy] = useState(false);

  async function submit() {
    if (!currentPw || !newPw || newPw !== confirmPw) {
      flash("Please fill all fields and confirm password", false);
      return;
    }
    if (newPw.length < 8) { flash("New password must be at least 8 characters", false); return; }
    setBusy(true);
    const r = await apiFetch("/admin/me/password", {
      method: "PATCH",
      body: JSON.stringify({ currentPassword: currentPw, newPassword: newPw }),
    });
    setBusy(false);
    if (r.ok) {
      flash("Password changed successfully!");
      setCurrentPw(""); setNewPw(""); setConfirmPw("");
    } else {
      const d = await r.json();
      flash(d.error ?? "Failed to change password", false);
    }
  }

  return (
    <div className="space-y-3">
      <h4 className="font-semibold text-sm" style={{ color: NAVY }}>Change Password</h4>
      <div className="relative">
        <Input type={showCurrent ? "text" : "password"} placeholder="Current password" value={currentPw}
          onChange={e => setCurrentPw(e.target.value)} className="pr-10" />
        <button onClick={() => setShowCurrent(p => !p)} className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"><Eye className="w-4 h-4" /></button>
      </div>
      <div className="relative">
        <Input type={showNew ? "text" : "password"} placeholder="New password (min 8 chars)" value={newPw}
          onChange={e => setNewPw(e.target.value)} className="pr-10" />
        <button onClick={() => setShowNew(p => !p)} className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"><Eye className="w-4 h-4" /></button>
      </div>
      <Input type="password" placeholder="Confirm new password" value={confirmPw}
        onChange={e => setConfirmPw(e.target.value)} className={confirmPw && newPw !== confirmPw ? "border-red-300" : ""} />
      <Button size="sm" className="text-white" style={{ background: ORANGE }}
        disabled={busy || !currentPw || !newPw || newPw !== confirmPw} onClick={submit}>
        {busy ? "Updating…" : "Update Password"}
      </Button>
    </div>
  );
}

export default function AdminPage() {
  return (
    <AdminErrorBoundary>
      <AdminPageInner />
    </AdminErrorBoundary>
  );
}
