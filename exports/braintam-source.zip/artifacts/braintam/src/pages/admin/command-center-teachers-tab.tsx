import { useState, useEffect, useCallback, useRef } from "react";
import {
  Search, Filter, ChevronDown, ChevronUp, ChevronLeft, ChevronRight,
  Loader2, XCircle, RefreshCw, MoreVertical, Eye, Pencil, UserCheck,
  UserX, Shield, X, Check, AlertTriangle, GraduationCap,
  BookOpen, Monitor, CalendarDays, Zap, TrendingUp, UserPlus, EyeOff,
} from "lucide-react";
import { API_BASE as BASE } from "@/lib/api-base";

const NAVY   = "#0B2B6B";
const ORANGE = "#FF6B1A";
const GREEN  = "#059669";

function apiFetch(path: string, opts?: RequestInit) {
  const token = localStorage.getItem("braintam_staff_token");
  return fetch(`${BASE}/api${path}`, {
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    credentials: "include",
    ...opts,
  });
}

// ── Types ─────────────────────────────────────────────────────────────────────
interface TeacherRow {
  id: number;
  name: string;
  email: string | null;
  phone: string | null;
  role: string;
  department: string | null;
  isActive: boolean;
  avatarUrl: string | null;
  createdAt: string;
  lastLoginDate: string | null;
  coursesCount: number;
  classesCount: number;
}

interface TeacherListResponse {
  items: TeacherRow[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
  kpis: { totalTeachers: number; activeTeachers: number; inactiveTeachers: number; totalClasses: number; totalCourses: number; avgAttendance: number };
}

interface ClassRow {
  id: number;
  title: string;
  subjectId: number | null;
  scheduledAt: string | null;
  status: string | null;
  grade: number | null;
}

// Teachers are department-neutral — assignable to any course or live class.

function StatusBadge({ isActive }: { isActive: boolean }) {
  return (
    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 w-fit ${isActive ? "bg-green-100 text-green-700" : "bg-red-100 text-red-600"}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${isActive ? "bg-green-500" : "bg-red-400"}`} />
      {isActive ? "Active" : "Inactive"}
    </span>
  );
}

function ClassStatusBadge({ status }: { status: string | null }) {
  const map: Record<string, { bg: string; text: string }> = {
    scheduled: { bg: "#DBEAFE", text: "#1E40AF" },
    live:      { bg: "#DCFCE7", text: "#166534" },
    completed: { bg: "#F1F5F9", text: "#475569" },
    cancelled: { bg: "#FEE2E2", text: "#991B1B" },
  };
  const s = map[status ?? ""] ?? { bg: "#F1F5F9", text: "#475569" };
  return <span className="text-[10px] font-bold px-2 py-0.5 rounded-full capitalize" style={{ background: s.bg, color: s.text }}>{status ?? "—"}</span>;
}

function Avatar({ name, avatarUrl, size = 8 }: { name: string; avatarUrl?: string | null; size?: number }) {
  const initials = name.split(" ").map(w => w[0]).slice(0, 2).join("").toUpperCase();
  if (avatarUrl) return <img src={avatarUrl} alt={name} className={`w-${size} h-${size} rounded-full object-cover flex-shrink-0`} />;
  return (
    <div className="rounded-full flex items-center justify-center text-white flex-shrink-0"
      style={{ background: NAVY, fontSize: size <= 8 ? "11px" : "14px", fontWeight: 900,
        width: `${size * 4}px`, height: `${size * 4}px`, minWidth: `${size * 4}px` }}>
      {initials || "?"}
    </div>
  );
}

function timeAgo(iso: string | null) {
  if (!iso) return "Never";
  const diff = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  if (diff < 60) return "Just now";
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  if (diff < 2592000) return `${Math.floor(diff / 86400)}d ago`;
  return new Date(iso).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
}

function fmtDate(iso: string | null) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
}

function fmtDateTime(iso: string | null) {
  if (!iso) return "—";
  return new Date(iso).toLocaleString("en-IN", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit", timeZone: "Asia/Kolkata" });
}

// ── Confirm Dialog ────────────────────────────────────────────────────────────
function ConfirmDialog({ title, message, confirmLabel, danger, onConfirm, onClose, loading }: {
  title: string; message: string; confirmLabel: string; danger?: boolean;
  onConfirm: () => void; onClose: () => void; loading?: boolean;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-5">
        <div className="flex items-center gap-3 mb-3">
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${danger ? "bg-red-100" : "bg-blue-50"}`}>
            <AlertTriangle className={`w-5 h-5 ${danger ? "text-red-500" : "text-blue-500"}`} />
          </div>
          <h3 className="font-black text-sm" style={{ color: NAVY }}>{title}</h3>
        </div>
        <p className="text-sm text-gray-500 mb-4">{message}</p>
        <div className="flex gap-2">
          <button onClick={onClose} disabled={loading} className="flex-1 px-4 py-2 rounded-xl text-xs font-bold border border-gray-200 text-gray-600 hover:bg-gray-50">Cancel</button>
          <button onClick={onConfirm} disabled={loading}
            className="flex-1 px-4 py-2 rounded-xl text-xs font-bold text-white flex items-center justify-center gap-1 disabled:opacity-60"
            style={{ background: danger ? "#EF4444" : NAVY }}>
            {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Edit Modal ────────────────────────────────────────────────────────────────
function EditModal({ teacher, onClose, onSaved, flash }: {
  teacher: TeacherRow; onClose: () => void;
  onSaved: (u: Partial<TeacherRow>) => void;
  flash: (m: string, ok?: boolean) => void;
}) {
  const [name, setName]       = useState(teacher.name);
  const [phone, setPhone]     = useState(teacher.phone ?? "");
  const [saving, setSaving]   = useState(false);

  async function save() {
    if (!name.trim()) return;
    setSaving(true);
    try {
      const r = await apiFetch(`/admin/cc/teachers/${teacher.id}`, {
        method: "PATCH",
        body: JSON.stringify({ name: name.trim(), phone: phone || null }),
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error ?? "Failed");
      flash("Teacher updated", true);
      onSaved(d.teacher);
      onClose();
    } catch (e) { flash(e instanceof Error ? e.message : "Failed", false); }
    finally { setSaving(false); }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm">
        <div className="flex items-center justify-between p-4 border-b border-gray-100">
          <h3 className="font-black text-sm" style={{ color: NAVY }}>Edit Teacher</h3>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded-lg"><X className="w-4 h-4 text-gray-400" /></button>
        </div>
        <div className="p-4 space-y-3">
          <div>
            <label className="text-xs font-semibold text-gray-500 block mb-1">Full Name *</label>
            <input value={name} onChange={e => setName(e.target.value)} placeholder="Full name"
              className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-blue-400" />
          </div>
          <div>
            <label className="text-xs font-semibold text-gray-500 block mb-1">Email (read-only)</label>
            <input value={teacher.email ?? "—"} readOnly className="w-full border border-gray-100 rounded-xl px-3 py-2 text-sm bg-gray-50 text-gray-400 cursor-not-allowed" />
          </div>
          <div>
            <label className="text-xs font-semibold text-gray-500 block mb-1">Phone</label>
            <input value={phone} onChange={e => setPhone(e.target.value)} placeholder="Phone number"
              className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-blue-400" />
          </div>
        </div>
        <div className="p-4 border-t border-gray-100 flex gap-2">
          <button onClick={onClose} className="flex-1 px-4 py-2 rounded-xl text-xs font-bold border border-gray-200 text-gray-600 hover:bg-gray-50">Cancel</button>
          <button onClick={save} disabled={saving || !name.trim()}
            className="flex-1 px-4 py-2 rounded-xl text-xs font-bold text-white flex items-center justify-center gap-1 disabled:opacity-60" style={{ background: NAVY }}>
            {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <><Check className="w-3.5 h-3.5" /> Save</>}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Add Teacher Modal ─────────────────────────────────────────────────────────
function AddTeacherModal({ onClose, onCreated, flash }: {
  onClose: () => void;
  onCreated: (t: TeacherRow) => void;
  flash: (m: string, ok?: boolean) => void;
}) {
  const [name, setName]         = useState("");
  const [email, setEmail]       = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw]     = useState(false);
  const [phone, setPhone]       = useState("");
  const [saving, setSaving]     = useState(false);

  async function create() {
    if (!name.trim() || !email.trim() || !password.trim()) return;
    setSaving(true);
    try {
      const r = await apiFetch("/admin/cc/teachers", {
        method: "POST",
        body: JSON.stringify({
          name: name.trim(),
          email: email.trim(),
          password: password.trim(),
          phone: phone || undefined,
        }),
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error ?? "Failed to create teacher");
      flash(`Teacher "${name.trim()}" created successfully`, true);
      onCreated(d.teacher);
      onClose();
    } catch (e) { flash(e instanceof Error ? e.message : "Failed", false); }
    finally { setSaving(false); }
  }

  const valid = name.trim().length > 0 && email.trim().length > 0 && password.trim().length > 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm">
        <div className="flex items-center justify-between p-4 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: `${NAVY}15` }}>
              <UserPlus className="w-3.5 h-3.5" style={{ color: NAVY }} />
            </div>
            <h3 className="font-black text-sm" style={{ color: NAVY }}>Add Teacher</h3>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded-lg"><X className="w-4 h-4 text-gray-400" /></button>
        </div>

        <div className="p-4 space-y-3">
          <div>
            <label className="text-xs font-semibold text-gray-500 block mb-1">Full Name <span className="text-red-400">*</span></label>
            <input value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Priya Sharma"
              className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-blue-400" />
          </div>
          <div>
            <label className="text-xs font-semibold text-gray-500 block mb-1">Email <span className="text-red-400">*</span></label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="teacher@braintam.com"
              className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-blue-400" />
          </div>
          <div>
            <label className="text-xs font-semibold text-gray-500 block mb-1">Password <span className="text-red-400">*</span></label>
            <div className="relative">
              <input type={showPw ? "text" : "password"} value={password} onChange={e => setPassword(e.target.value)} placeholder="Minimum 6 characters"
                className="w-full border border-gray-200 rounded-xl px-3 py-2 pr-9 text-sm focus:outline-none focus:border-blue-400" />
              <button type="button" onClick={() => setShowPw(s => !s)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                {showPw ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>
          <div>
            <label className="text-xs font-semibold text-gray-500 block mb-1">Phone <span className="text-gray-300 font-normal">(optional)</span></label>
            <input value={phone} onChange={e => setPhone(e.target.value)} placeholder="10-digit mobile number"
              className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-blue-400" />
          </div>
        </div>

        <div className="p-4 border-t border-gray-100 flex gap-2">
          <button onClick={onClose} disabled={saving} className="flex-1 px-4 py-2 rounded-xl text-xs font-bold border border-gray-200 text-gray-600 hover:bg-gray-50">Cancel</button>
          <button onClick={create} disabled={saving || !valid}
            className="flex-1 px-4 py-2 rounded-xl text-xs font-bold text-white flex items-center justify-center gap-1 disabled:opacity-60"
            style={{ background: NAVY }}>
            {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <><UserPlus className="w-3.5 h-3.5" /> Create</>}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Profile Modal ─────────────────────────────────────────────────────────────
interface ProfileData {
  profile: TeacherRow;
  performance: { classesAssigned: number; coursesAssigned: number; subjects: string[]; attendancePct: number; homeworkCompletionPct: number };
  permissions: { module: string; view: boolean; create: boolean; edit: boolean; del: boolean }[];
  activity: { id: number; action: string; actionLabel: string; module: string; targetName: string; createdAt: string }[];
}

function ProfileModal({ teacherId, onClose }: { teacherId: number; onClose: () => void }) {
  const [data, setData]         = useState<ProfileData | null>(null);
  const [loading, setLoading]   = useState(true);
  const [classes, setClasses]   = useState<ClassRow[]>([]);
  const [classesLoading, setClassesLoading] = useState(false);
  const [activeTab, setTab]     = useState<"performance"|"classes"|"permissions"|"activity">("performance");

  useEffect(() => {
    apiFetch(`/admin/cc/teachers/${teacherId}`)
      .then(r => r.json()).then(setData).catch(() => {}).finally(() => setLoading(false));
  }, [teacherId]);

  useEffect(() => {
    if (activeTab !== "classes" || classes.length > 0) return;
    setClassesLoading(true);
    apiFetch(`/admin/cc/teachers/${teacherId}/classes?limit=50`)
      .then(r => r.json()).then(d => setClasses(d.items ?? [])).catch(() => {}).finally(() => setClassesLoading(false));
  }, [activeTab, teacherId]);

  if (loading) return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
      <div className="bg-white rounded-2xl p-8 shadow-2xl flex items-center gap-3">
        <Loader2 className="w-5 h-5 animate-spin" style={{ color: NAVY }} />
        <span className="text-sm font-semibold text-gray-500">Loading profile…</span>
      </div>
    </div>
  );
  if (!data) return null;

  const { profile, performance, permissions, activity } = data;
  const tabs = [
    { key: "performance" as const, label: "Performance",  icon: TrendingUp  },
    { key: "classes"     as const, label: "Classes",      icon: Monitor     },
    { key: "permissions" as const, label: "Permissions",  icon: Shield      },
    { key: "activity"    as const, label: "Activity",     icon: Zap         },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-100 flex-shrink-0">
          <div className="flex items-center gap-3">
            <Avatar name={profile.name} avatarUrl={profile.avatarUrl} size={10} />
            <div>
              <p className="font-black text-sm" style={{ color: NAVY }}>{profile.name}</p>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{ background: "#E0F2FE", color: "#0C4A6E" }}>
                  <GraduationCap className="inline w-2.5 h-2.5 mr-0.5" />Teacher
                </span>
                <StatusBadge isActive={profile.isActive} />
              </div>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 hover:bg-gray-100 rounded-lg"><X className="w-4 h-4 text-gray-400" /></button>
        </div>

        {/* Info strip */}
        <div className="px-4 py-2 bg-gray-50 border-b border-gray-100 flex flex-wrap gap-3 text-xs text-gray-500 flex-shrink-0">
          <span>{profile.email ?? "—"}</span>
          <span>·</span><span>{profile.phone ?? "—"}</span>
          <span>·</span><span>Joined {fmtDate(profile.createdAt)}</span>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-100 flex-shrink-0 overflow-x-auto">
          {tabs.map(t => {
            const Icon = t.icon;
            return (
              <button key={t.key} onClick={() => setTab(t.key)}
                className="flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap"
                style={activeTab === t.key ? { borderColor: NAVY, color: NAVY } : { borderColor: "transparent", color: "#9CA3AF" }}>
                <Icon className="w-3.5 h-3.5" />{t.label}
              </button>
            );
          })}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4">
          {activeTab === "performance" && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                {[
                  { label: "Classes Assigned",  value: performance.classesAssigned,  color: NAVY    },
                  { label: "Courses Assigned",  value: performance.coursesAssigned,  color: "#7C3AED" },
                  { label: "Attendance %",      value: `${performance.attendancePct}%`,  color: GREEN  },
                  { label: "Homework Completion",value: `${performance.homeworkCompletionPct}%`, color: ORANGE },
                  { label: "Last Active",       value: timeAgo(profile.lastLoginDate), color: "#374151" },
                ].map(s => (
                  <div key={s.label} className="bg-gray-50 rounded-xl p-3">
                    <p className="text-[10px] text-gray-400 mb-1">{s.label}</p>
                    <p className="text-xl font-black" style={{ color: s.color }}>{s.value}</p>
                  </div>
                ))}
              </div>
              {performance.subjects.length > 0 && (
                <div>
                  <p className="text-xs font-bold text-gray-500 mb-2 flex items-center gap-1.5"><BookOpen className="w-3.5 h-3.5" />Subjects</p>
                  <div className="flex flex-wrap gap-1.5">
                    {performance.subjects.map(s => (
                      <span key={s} className="text-[11px] font-semibold px-2.5 py-1 rounded-full bg-blue-50 text-blue-700">{s}</span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === "classes" && (
            <div>
              {classesLoading ? (
                <div className="flex items-center justify-center py-10 gap-2 text-gray-400">
                  <Loader2 className="w-5 h-5 animate-spin" style={{ color: NAVY }} />
                  <span className="text-sm">Loading classes…</span>
                </div>
              ) : classes.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-10 gap-2 text-gray-400">
                  <Monitor className="w-8 h-8 text-gray-200" />
                  <p className="text-sm font-semibold">No classes assigned</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {classes.map(c => (
                    <div key={c.id} className="flex items-center justify-between px-3 py-2.5 rounded-xl bg-gray-50">
                      <div>
                        <p className="text-xs font-semibold text-gray-800">{c.title}</p>
                        <p className="text-[10px] text-gray-400">Subject #{c.subjectId ?? "—"} · Grade {c.grade ?? "—"}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <ClassStatusBadge status={c.status} />
                        <span className="text-[10px] text-gray-400 whitespace-nowrap">{fmtDateTime(c.scheduledAt)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === "permissions" && (
            <div>
              <p className="text-xs text-gray-400 mb-3 flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5" />
                Read-only view — editable in Phase D (Roles &amp; Permissions module).
              </p>
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="border-b border-gray-100">
                      <th className="text-left px-3 py-2 text-[10px] font-bold text-gray-400 uppercase tracking-wider">Module</th>
                      {["View","Create","Edit","Delete"].map(h => (
                        <th key={h} className="px-3 py-2 text-[10px] font-bold text-gray-400 uppercase tracking-wider text-center">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {permissions.map(p => (
                      <tr key={p.module}>
                        <td className="px-3 py-2 font-medium text-gray-700">{p.module}</td>
                        {[p.view, p.create, p.edit, p.del].map((v, i) => (
                          <td key={i} className="px-3 py-2 text-center">
                            <span className={`inline-flex items-center justify-center w-5 h-5 rounded-full text-[10px] font-black ${v ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-400"}`}>
                              {v ? "✓" : "×"}
                            </span>
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === "activity" && (
            <div className="space-y-2">
              {activity.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-10 gap-2 text-gray-400">
                  <Zap className="w-8 h-8 text-gray-200" />
                  <p className="text-sm font-semibold">No activity yet</p>
                </div>
              ) : activity.map(a => (
                <div key={a.id} className="flex items-center justify-between px-3 py-2.5 rounded-xl bg-gray-50">
                  <div>
                    <p className="text-xs font-semibold text-gray-700">{a.actionLabel ?? a.action}</p>
                    <p className="text-[10px] text-gray-400">{a.targetName} · {a.module}</p>
                  </div>
                  <span className="text-[10px] text-gray-400 whitespace-nowrap">{timeAgo(a.createdAt)}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ── Row Actions Menu ──────────────────────────────────────────────────────────
function ActionsMenu({ teacher, onAction }: {
  teacher: TeacherRow;
  onAction: (a: "view"|"edit"|"toggle-status"|"view-classes") => void;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handler(e: MouseEvent) { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); }
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const actions = [
    { key: "view"          as const, label: "View Profile",  icon: Eye,         color: NAVY    },
    { key: "edit"          as const, label: "Edit Teacher",  icon: Pencil,      color: "#374151" },
    { key: "toggle-status" as const, label: teacher.isActive ? "Deactivate" : "Activate", icon: teacher.isActive ? UserX : UserCheck, color: teacher.isActive ? "#EF4444" : GREEN },
    { key: "view-classes"  as const, label: "View Classes",  icon: Monitor,     color: ORANGE  },
  ];

  return (
    <div ref={ref} className="relative">
      <button onClick={() => setOpen(o => !o)} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-colors">
        <MoreVertical className="w-4 h-4" />
      </button>
      {open && (
        <div className="absolute right-0 top-7 z-20 bg-white rounded-xl shadow-xl border border-gray-100 py-1 w-40">
          {actions.map(a => {
            const Icon = a.icon;
            return (
              <button key={a.key} onClick={() => { setOpen(false); onAction(a.key); }}
                className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium hover:bg-gray-50 transition-colors"
                style={{ color: a.color }}>
                <Icon className="w-3.5 h-3.5 flex-shrink-0" />{a.label}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ── Main Teacher Management Component ────────────────────────────────────────
export function TeacherManagementView({ flash }: { flash: (msg: string, ok?: boolean) => void }) {
  const [data, setData]             = useState<TeacherListResponse | null>(null);
  const [loading, setLoading]       = useState(true);
  const [error, setError]           = useState<string | null>(null);
  const [search, setSearch]         = useState("");
  const [statusFilter, setStatus]   = useState("all");
  const [sort, setSort]             = useState("name");
  const [order, setOrder]           = useState<"asc"|"desc">("asc");
  const [page, setPage]             = useState(1);
  const [showFilters, setShowFilters] = useState(false);

  const [profileId, setProfileId]     = useState<number | null>(null);
  const [editTeacher, setEditTeacher] = useState<TeacherRow | null>(null);
  const [toggleTarget, setToggleTarget] = useState<TeacherRow | null>(null);
  const [actionLoading, setActionLoading] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);

  const debouncedSearch = useDebounce(search, 300);

  const load = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const p = new URLSearchParams({ search: debouncedSearch, status: statusFilter, sort, order, page: String(page), limit: "15" });
      const r = await apiFetch(`/admin/cc/teachers?${p}`);
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      setData(await r.json());
    } catch (e) { setError(e instanceof Error ? e.message : "Failed"); }
    finally { setLoading(false); }
  }, [debouncedSearch, statusFilter, sort, order, page]);

  useEffect(() => { setPage(1); }, [debouncedSearch, statusFilter]);
  useEffect(() => { load(); }, [load]);

  function updateRow(id: number, changes: Partial<TeacherRow>) {
    setData(d => d ? { ...d, items: d.items.map(t => t.id === id ? { ...t, ...changes } : t) } : d);
  }

  async function doToggle() {
    if (!toggleTarget) return;
    setActionLoading(true);
    try {
      const r = await apiFetch(`/admin/cc/teachers/${toggleTarget.id}`, {
        method: "PATCH", body: JSON.stringify({ isActive: !toggleTarget.isActive }),
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error ?? "Failed");
      updateRow(toggleTarget.id, { isActive: !toggleTarget.isActive });
      flash(`${toggleTarget.name} ${toggleTarget.isActive ? "deactivated" : "activated"}`, true);
    } catch (e) { flash(e instanceof Error ? e.message : "Failed", false); }
    finally { setActionLoading(false); setToggleTarget(null); }
  }

  function toggleSort(col: string) {
    if (sort === col) setOrder(o => o === "asc" ? "desc" : "asc");
    else { setSort(col); setOrder("asc"); }
  }

  const SortIcon = ({ col }: { col: string }) => (
    sort === col
      ? (order === "asc" ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />)
      : <ChevronDown className="w-3 h-3 opacity-20" />
  );

  const kpis = data?.kpis;

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-black" style={{ color: NAVY }}>Teacher Management</h2>
          <p className="text-xs text-gray-400 mt-0.5">Operational directory for all Braintam teachers</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={load} className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-gray-500 hover:bg-gray-100 border border-gray-200">
            <RefreshCw className="w-3 h-3" /> Refresh
          </button>
          <button onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold text-white shadow-sm"
            style={{ background: NAVY }}>
            <UserPlus className="w-3.5 h-3.5" /> Add Teacher
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
        {[
          { label: "Total",         value: kpis?.totalTeachers ?? "—",   icon: <GraduationCap className="w-4 h-4" />, color: NAVY    },
          { label: "Active",        value: kpis?.activeTeachers ?? "—",  icon: <UserCheck className="w-4 h-4" />,    color: GREEN   },
          { label: "Inactive",      value: kpis?.inactiveTeachers ?? "—",icon: <UserX className="w-4 h-4" />,        color: "#EF4444" },
          { label: "Avg Attendance",value: kpis ? `${kpis.avgAttendance}%` : "—", icon: <CalendarDays className="w-4 h-4" />, color: ORANGE },
          { label: "Classes",       value: kpis?.totalClasses ?? "—",    icon: <Monitor className="w-4 h-4" />,      color: "#7C3AED" },
          { label: "Courses",       value: kpis?.totalCourses ?? "—",    icon: <BookOpen className="w-4 h-4" />,     color: "#0284C7" },
        ].map(k => (
          <div key={k.label} className="bg-white rounded-xl p-3 border border-gray-100 shadow-sm text-center">
            <div className="flex justify-center mb-1" style={{ color: k.color }}>{k.icon}</div>
            <div className="text-xl font-black" style={{ color: k.color }}>{loading ? "—" : k.value}</div>
            <div className="text-[10px] text-gray-400 font-medium mt-0.5">{k.label}</div>
          </div>
        ))}
      </div>

      {/* Search + Filters */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-3 space-y-2">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by name, phone or email…"
              className="w-full pl-9 pr-3 py-2 text-sm border border-gray-200 rounded-xl focus:outline-none focus:border-blue-400" />
            {search && <button onClick={() => setSearch("")} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"><X className="w-3.5 h-3.5" /></button>}
          </div>
          <button onClick={() => setShowFilters(f => !f)}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold border transition-colors"
            style={showFilters ? { background: `${NAVY}10`, borderColor: NAVY, color: NAVY } : { borderColor: "#E5E7EB", color: "#6B7280" }}>
            <Filter className="w-3.5 h-3.5" /> Filters
            {statusFilter !== "all" && <span className="w-1.5 h-1.5 rounded-full bg-orange-500" />}
          </button>
        </div>
        {showFilters && (
          <div className="flex flex-wrap gap-2 pt-1">
            <select value={statusFilter} onChange={e => setStatus(e.target.value)}
              className="border border-gray-200 rounded-xl px-3 py-1.5 text-xs font-medium focus:outline-none">
              <option value="all">All Status</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
            {statusFilter !== "all" && (
              <button onClick={() => setStatus("all")}
                className="text-xs font-semibold text-orange-500 hover:underline px-2">Clear</button>
            )}
          </div>
        )}
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center py-20 gap-2 text-gray-400">
            <Loader2 className="w-6 h-6 animate-spin" style={{ color: NAVY }} />
            <span className="text-sm">Loading teachers…</span>
          </div>
        ) : error ? (
          <div className="flex flex-col items-center justify-center py-20 gap-3">
            <XCircle className="w-8 h-8 text-red-400" />
            <p className="text-sm font-semibold text-red-600">{error}</p>
            <button onClick={load} className="px-4 py-1.5 rounded-xl text-xs font-bold text-white" style={{ background: NAVY }}>Retry</button>
          </div>
        ) : !data || data.items.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 gap-3 text-gray-400">
            <GraduationCap className="w-10 h-10 text-gray-200" />
            <p className="text-sm font-semibold">No teachers found</p>
            <p className="text-xs text-gray-300">{search || statusFilter !== "all" ? "Try adjusting your filters" : "No teacher accounts yet"}</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-gray-100">
                  {[
                    { label: "Teacher",      col: "name",         sortable: true  },
                    { label: "Courses",      col: "coursesCount", sortable: true  },
                    { label: "Classes",      col: "classesCount", sortable: true  },
                    { label: "Status",       col: "status",       sortable: false },
                    { label: "Joined",       col: "createdAt",    sortable: true  },
                    { label: "Last Active",  col: "lastActive",   sortable: true  },
                    { label: "",             col: "actions",      sortable: false },
                  ].map(h => (
                    <th key={h.col}
                      className={`text-left px-4 py-3 text-[10px] font-bold text-gray-400 uppercase tracking-wider ${h.sortable ? "cursor-pointer hover:text-gray-600 select-none" : ""}`}
                      onClick={() => h.sortable && toggleSort(h.col)}>
                      <span className="flex items-center gap-1">{h.label}{h.sortable && <SortIcon col={h.col} />}</span>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {data.items.map(t => (
                  <tr key={t.id} className="hover:bg-gray-50/50 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2.5">
                        <Avatar name={t.name} avatarUrl={t.avatarUrl} />
                        <div>
                          <p className="font-semibold text-gray-800">{t.name}</p>
                          <p className="text-[10px] text-gray-400">{t.email ?? t.phone ?? "—"}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className="font-bold text-gray-700">{t.coursesCount}</span>
                      <span className="text-gray-400 ml-1">courses</span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="font-bold text-gray-700">{t.classesCount}</span>
                      <span className="text-gray-400 ml-1">classes</span>
                    </td>
                    <td className="px-4 py-3"><StatusBadge isActive={t.isActive} /></td>
                    <td className="px-4 py-3 text-gray-500 whitespace-nowrap">{fmtDate(t.createdAt)}</td>
                    <td className="px-4 py-3 text-gray-500 whitespace-nowrap">{timeAgo(t.lastLoginDate)}</td>
                    <td className="px-4 py-3">
                      <ActionsMenu teacher={t} onAction={action => {
                        if (action === "view")          setProfileId(t.id);
                        else if (action === "edit")     setEditTeacher(t);
                        else if (action === "toggle-status") setToggleTarget(t);
                        else if (action === "view-classes")  setProfileId(t.id);
                      }} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Pagination */}
      {data && data.totalPages > 1 && (
        <div className="flex items-center justify-between bg-white rounded-xl px-4 py-2.5 border border-gray-100 shadow-sm">
          <p className="text-xs text-gray-400">
            Showing {((data.page - 1) * data.pageSize) + 1}–{Math.min(data.page * data.pageSize, data.total)} of {data.total}
          </p>
          <div className="flex items-center gap-1">
            <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={data.page <= 1}
              className="p-1.5 rounded-lg border border-gray-200 disabled:opacity-40 hover:bg-gray-50"><ChevronLeft className="w-3.5 h-3.5 text-gray-500" /></button>
            {Array.from({ length: Math.min(5, data.totalPages) }, (_, i) => {
              const pg = data.totalPages <= 5 ? i + 1 : Math.max(1, Math.min(data.page - 2, data.totalPages - 4)) + i;
              return (
                <button key={pg} onClick={() => setPage(pg)}
                  className={`w-7 h-7 rounded-lg text-xs font-bold transition-colors ${pg === data.page ? "text-white" : "text-gray-500 hover:bg-gray-50 border border-gray-200"}`}
                  style={pg === data.page ? { background: NAVY } : {}}>
                  {pg}
                </button>
              );
            })}
            <button onClick={() => setPage(p => Math.min(data.totalPages, p + 1))} disabled={data.page >= data.totalPages}
              className="p-1.5 rounded-lg border border-gray-200 disabled:opacity-40 hover:bg-gray-50"><ChevronRight className="w-3.5 h-3.5 text-gray-500" /></button>
          </div>
        </div>
      )}

      {/* Modals */}
      {showAddModal && (
        <AddTeacherModal
          onClose={() => setShowAddModal(false)}
          onCreated={t => { load(); }}
          flash={flash}
        />
      )}
      {profileId    && <ProfileModal teacherId={profileId} onClose={() => setProfileId(null)} />}
      {editTeacher  && <EditModal teacher={editTeacher} onClose={() => setEditTeacher(null)} onSaved={u => updateRow(editTeacher.id, u)} flash={flash} />}
      {toggleTarget && (
        <ConfirmDialog
          title={toggleTarget.isActive ? "Deactivate Teacher" : "Activate Teacher"}
          message={toggleTarget.isActive ? `${toggleTarget.name} will no longer be able to log in.` : `${toggleTarget.name} will regain access.`}
          confirmLabel={toggleTarget.isActive ? "Deactivate" : "Activate"}
          danger={toggleTarget.isActive}
          onConfirm={doToggle}
          onClose={() => setToggleTarget(null)}
          loading={actionLoading}
        />
      )}
    </div>
  );
}

function useDebounce<T>(value: T, delay: number): T {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(t);
  }, [value, delay]);
  return debounced;
}
