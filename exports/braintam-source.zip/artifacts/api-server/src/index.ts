import { createServer } from "http";
import app from "./app";
import { logger } from "./lib/logger";
import { setupSocketIO } from "./socket.js";
import { runOverdueFollowUpReminders } from "./jobs/overdueFollowUpReminders.js";
import { scheduleDailyQueueReset } from "./jobs/dailyQueueReset.js";
import { scheduleSundayBatchRotation } from "./jobs/sundayBatchRotation.js";
import { scheduleLiveClassStatusSync } from "./jobs/liveClassStatusSync.js";
import { seedCoursePricing } from "./routes/longTermPayments.js";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error("PORT environment variable is required but was not provided.");
}

const port = Number(rawPort);
if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

const httpServer = createServer(app);
setupSocketIO(httpServer);

httpServer.listen(port, (err?: Error) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
  scheduleReminderJob();
  scheduleDailyQueueReset();
  scheduleSundayBatchRotation();
  scheduleLiveClassStatusSync();
  seedCoursePricing().catch(e => logger.error({ err: e }, "Course pricing seed failed"));
});

function scheduleReminderJob(): void {
  const CHECK_INTERVAL_MS = 30 * 60 * 1000;

  const runWithGuard = async () => {
    try {
      await runOverdueFollowUpReminders();
    } catch (err) {
      logger.error({ err }, "Overdue follow-up reminder job failed");
    }
  };

  setInterval(runWithGuard, CHECK_INTERVAL_MS);
  logger.info({ intervalMinutes: 30 }, "Overdue follow-up reminder job scheduled (runs every 30 min)");
}
